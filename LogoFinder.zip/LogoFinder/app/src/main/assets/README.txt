Codemagic downloads the AI models into this folder automatically.
