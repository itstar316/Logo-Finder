The AI model is downloaded here automatically by Codemagic.
