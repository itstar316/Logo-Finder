package com.k2.logofinder

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt

private enum class DragMode { NONE, MOVE, TL, TR, BL, BR }

/** Drag the box (or its corners) around just the logo, then search with that part only. */
@Composable
fun CropScreen(bitmap: Bitmap, onCancel: () -> Unit, onCrop: (Bitmap) -> Unit) {
    // Box position as fractions of the picture (0..1), so it works at any screen size.
    var box by remember(bitmap) { mutableStateOf(Rect(0.1f, 0.1f, 0.9f, 0.9f)) }
    var area by remember { mutableStateOf(IntSize.Zero) }
    var mode by remember { mutableStateOf(DragMode.NONE) }
    val handleRadiusPx = with(LocalDensity.current) { 36.dp.toPx() }

    // Where the picture is drawn inside the area (it is fitted, keeping its shape).
    fun imageRect(): Rect {
        if (area.width == 0 || area.height == 0) return Rect.Zero
        val scale = min(area.width.toFloat() / bitmap.width, area.height.toFloat() / bitmap.height)
        val w = bitmap.width * scale
        val h = bitmap.height * scale
        val left = (area.width - w) / 2
        val top = (area.height - h) / 2
        return Rect(left, top, left + w, top + h)
    }

    fun toScreen(r: Rect): Rect {
        val img = imageRect()
        return Rect(
            img.left + r.left * img.width, img.top + r.top * img.height,
            img.left + r.right * img.width, img.top + r.bottom * img.height
        )
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Drag the box around the logo", style = MaterialTheme.typography.titleLarge)
        Text(
            "Drag the corners to resize. Leave out the jacket, background and other things.",
            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(12.dp))

        Box(
            Modifier.weight(1f).fillMaxWidth().onSizeChanged { area = it }
        ) {
            Image(
                bitmap.asImageBitmap(), contentDescription = "Client's picture",
                contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize()
            )
            Canvas(
                Modifier.fillMaxSize().pointerInput(bitmap) {
                    val minSize = 0.05f
                    detectDragGestures(
                        onDragStart = { pos ->
                            val s = toScreen(box)
                            val corners = listOf(
                                DragMode.TL to Offset(s.left, s.top),
                                DragMode.TR to Offset(s.right, s.top),
                                DragMode.BL to Offset(s.left, s.bottom),
                                DragMode.BR to Offset(s.right, s.bottom)
                            )
                            val nearest = corners.minByOrNull { (_, c) -> hypot(c.x - pos.x, c.y - pos.y) }!!
                            mode = when {
                                hypot(nearest.second.x - pos.x, nearest.second.y - pos.y) < handleRadiusPx -> nearest.first
                                s.contains(pos) -> DragMode.MOVE
                                else -> DragMode.NONE
                            }
                        },
                        onDragEnd = { mode = DragMode.NONE },
                        onDragCancel = { mode = DragMode.NONE },
                        onDrag = { change, drag ->
                            change.consume()
                            val img = imageRect()
                            if (img.width <= 0f || img.height <= 0f) return@detectDragGestures
                            val dx = drag.x / img.width
                            val dy = drag.y / img.height
                            val b = box
                            box = when (mode) {
                                DragMode.MOVE -> {
                                    val mx = dx.coerceIn(-b.left, 1f - b.right)
                                    val my = dy.coerceIn(-b.top, 1f - b.bottom)
                                    Rect(b.left + mx, b.top + my, b.right + mx, b.bottom + my)
                                }
                                DragMode.TL -> Rect(
                                    (b.left + dx).coerceIn(0f, b.right - minSize),
                                    (b.top + dy).coerceIn(0f, b.bottom - minSize), b.right, b.bottom
                                )
                                DragMode.TR -> Rect(
                                    b.left, (b.top + dy).coerceIn(0f, b.bottom - minSize),
                                    (b.right + dx).coerceIn(b.left + minSize, 1f), b.bottom
                                )
                                DragMode.BL -> Rect(
                                    (b.left + dx).coerceIn(0f, b.right - minSize), b.top,
                                    b.right, (b.bottom + dy).coerceIn(b.top + minSize, 1f)
                                )
                                DragMode.BR -> Rect(
                                    b.left, b.top,
                                    (b.right + dx).coerceIn(b.left + minSize, 1f),
                                    (b.bottom + dy).coerceIn(b.top + minSize, 1f)
                                )
                                DragMode.NONE -> b
                            }
                        }
                    )
                }
            ) {
                val img = imageRect()
                val s = toScreen(box)
                val shade = Color.Black.copy(alpha = 0.55f)
                // Darken everything outside the box
                drawRect(shade, Offset(img.left, img.top), Size(img.width, s.top - img.top))
                drawRect(shade, Offset(img.left, s.bottom), Size(img.width, img.bottom - s.bottom))
                drawRect(shade, Offset(img.left, s.top), Size(s.left - img.left, s.height))
                drawRect(shade, Offset(s.right, s.top), Size(img.right - s.right, s.height))
                drawRect(Color.White, s.topLeft, s.size, style = Stroke(width = 3.dp.toPx()))
                listOf(s.topLeft, s.topRight, s.bottomLeft, s.bottomRight).forEach {
                    drawRoundRect(
                        Palette.Thread,
                        topLeft = Offset(it.x - 12.dp.toPx(), it.y - 12.dp.toPx()),
                        size = Size(24.dp.toPx(), 24.dp.toPx()),
                        cornerRadius = CornerRadius(6.dp.toPx())
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Cancel") }
            Button(
                onClick = {
                    val l = (box.left * bitmap.width).roundToInt().coerceIn(0, bitmap.width - 1)
                    val t = (box.top * bitmap.height).roundToInt().coerceIn(0, bitmap.height - 1)
                    val r = (box.right * bitmap.width).roundToInt().coerceIn(l + 1, bitmap.width)
                    val b = (box.bottom * bitmap.height).roundToInt().coerceIn(t + 1, bitmap.height)
                    onCrop(Bitmap.createBitmap(bitmap, l, t, r - l, b - t))
                },
                modifier = Modifier.weight(1f)
            ) { Text("Search this part") }
        }
    }
}
