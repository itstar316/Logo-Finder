package com.k2.logofinder

import android.content.Context
import android.graphics.Bitmap
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.imageembedder.ImageEmbedder
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await
import java.io.Closeable

/** A logo's "fingerprint": several visual views plus any words written in it. */
class Fingerprint(val views: List<FloatArray>, val words: Set<String>)

/**
 * Runs fully on the phone, no internet needed.
 * Visual part: MediaPipe Image Embedder (file in app/src/main/assets).
 * Text part: Google ML Kit text recognition.
 * To try a stronger model later, only this class needs to change.
 */
class LogoEngine(context: Context) : Closeable {

    private val embedder: ImageEmbedder = ImageEmbedder.createFromOptions(
        context,
        ImageEmbedder.ImageEmbedderOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetPath(MODEL_FILE).build())
            .setL2Normalize(true)
            .setQuantize(false)
            .setRunningMode(RunningMode.IMAGE)
            .build()
    )

    private val ocr = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    @Synchronized
    private fun embed(bmp: Bitmap): FloatArray =
        embedder.embed(BitmapImageBuilder(bmp).build())
            .embeddingResult().embeddings()[0].floatEmbedding()

    private suspend fun readWords(bmp: Bitmap): Set<String> = try {
        Matcher.tokens(ocr.process(InputImage.fromBitmap(bmp, 0)).await().text)
    } catch (e: Exception) {
        emptySet()
    }

    /** For your Wilcom pictures: trimmed logo in colour + black and white. */
    suspend fun fingerprintLogo(bmp: Bitmap): Fingerprint {
        val trimmed = Images.trimBackground(bmp)
        return Fingerprint(
            views = listOf(embed(trimmed), embed(Images.gray(trimmed))),
            words = readWords(trimmed)
        )
    }

    /** For the client's picture: also tries the middle of the photo, in case the logo is small. */
    suspend fun fingerprintQuery(bmp: Bitmap): Fingerprint {
        val trimmed = Images.trimBackground(bmp)
        val middle = Images.centerCrop(bmp, 0.6f)
        return Fingerprint(
            views = listOf(trimmed, Images.gray(trimmed), middle, Images.gray(middle)).map { embed(it) },
            words = readWords(bmp)
        )
    }

    override fun close() {
        embedder.close()
        ocr.close()
    }

    companion object {
        const val MODEL_FILE = "mobilenet_v3_large.tflite"
    }
}
