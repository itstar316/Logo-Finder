package com.k2.logofinder

import android.content.Context
import android.graphics.Bitmap
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.imageembedder.ImageEmbedder
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await
import java.io.Closeable

/** One look at a picture, through both AI models. */
class LogoView(val dino: Vec, val mobile: Vec, val weight: Float = 1f)

/** A picture's fingerprint: several views plus any words written in it. */
class Fingerprint(val views: List<LogoView>, val words: Set<String>)

/**
 * Runs fully on the phone, no internet needed.
 * - DINOv2 (main model): strong at matching the same design across quality differences.
 * - MobileNet (MediaPipe): a second opinion from a different kind of model.
 * - ML Kit: reads words written in the logo.
 */
class LogoEngine(context: Context) : Closeable {

    private val dino = DinoEmbedder(context)

    private val mobile: ImageEmbedder = ImageEmbedder.createFromOptions(
        context,
        ImageEmbedder.ImageEmbedderOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetPath(MOBILE_MODEL).build())
            .setL2Normalize(true)
            .setQuantize(false)
            .setRunningMode(RunningMode.IMAGE)
            .build()
    )

    private val ocr = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    @Synchronized
    private fun mobileEmbed(bmp: Bitmap): FloatArray =
        mobile.embed(BitmapImageBuilder(bmp).build())
            .embeddingResult().embeddings()[0].floatEmbedding()

    private fun view(bmp: Bitmap, weight: Float = 1f): LogoView {
        val square = Images.padToSquare(bmp)
        return LogoView(Vec.of(dino.embed(square)), Vec.of(normalize(mobileEmbed(square))), weight)
    }

    private fun normalize(v: FloatArray): FloatArray {
        var sum = 0f
        for (x in v) sum += x * x
        val n = kotlin.math.sqrt(sum)
        if (n > 0f) for (i in v.indices) v[i] /= n
        return v
    }

    private suspend fun readWords(bmp: Bitmap): Set<String> = try {
        Matcher.tokens(ocr.process(InputImage.fromBitmap(Images.upscaleForText(bmp), 0)).await().text)
    } catch (e: Exception) {
        emptySet()
    } catch (e: OutOfMemoryError) {
        emptySet()
    }

    /** For your Wilcom pictures. */
    suspend fun fingerprintLogo(bmp: Bitmap): Fingerprint {
        val clean = Images.autoContrast(Images.trimBackground(bmp))
        return Fingerprint(
            views = listOf(view(clean), view(Images.gray(clean))),
            words = readWords(clean)
        )
    }

    /**
     * For the client's picture. Looks at the whole picture and, unless you cropped it yourself,
     * also at the middle part (in case the logo is small in the photo).
     */
    suspend fun fingerprintQuery(bmp: Bitmap, userCropped: Boolean): Fingerprint {
        val clean = Images.autoContrast(Images.trimBackground(bmp))
        val views = mutableListOf(view(clean), view(Images.gray(clean)))
        if (!userCropped) {
            val middle = Images.autoContrast(Images.centerCrop(bmp, 0.6f))
            views += view(middle, CROP_WEIGHT)
            views += view(Images.gray(middle), CROP_WEIGHT)
        }
        val words = readWords(clean).ifEmpty { readWords(bmp) }
        return Fingerprint(views, words)
    }

    override fun close() {
        dino.close()
        mobile.close()
        ocr.close()
    }

    companion object {
        const val MOBILE_MODEL = "mobilenet_v3_large.tflite"
        /** Partial views count slightly less, so they don't push random logos up. */
        private const val CROP_WEIGHT = 0.95f
    }
}
