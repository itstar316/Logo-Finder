package com.k2.logofinder

import android.content.Context
import android.net.Uri
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

/**
 * Sharing the work between phones.
 *
 * Export: writes a ".k2lib" file with the fingerprint of every logo already read (and your confirmed
 * client pictures). It does NOT contain the logo pictures themselves.
 *
 * Import: your partner opens that file, then chooses his own copy of the same logo folder.
 * Every picture that matches (same place in the folder, or same file name and size) uses the
 * shared fingerprint instantly; only pictures missing from the file are read by the AI.
 */
object SharedLibrary {
    private const val MAGIC = "K2LIB"
    private const val FORMAT = 1
    /** Change this if the AI models or picture preparation ever change, so old files are refused. */
    const val ENGINE = 1
    private const val SEED_FILE = "shared_seed.k2lib"

    class SeedEntry(val relPath: String, val fileName: String, val size: Long, val fp: Fingerprint, val learned: List<Fingerprint>)

    class Seed(entries: List<SeedEntry>) {
        val count = entries.size
        private val byPath = entries.associateBy { it.relPath.lowercase() }
        private val byNameSize = entries.groupBy { "${it.fileName.lowercase()}|${it.size}" }
            .filterValues { it.size == 1 }.mapValues { it.value[0] }

        fun match(f: ImageFile): SeedEntry? {
            val p = byPath[f.relPath.lowercase()]
            if (p != null && (p.size == 0L || f.size == 0L || p.size == f.size)) return p
            if (f.size > 0L) return byNameSize["${f.name.lowercase()}|${f.size}"]
            return null
        }
    }

    /** Creates the file to send to a partner. Returns the file and how many logos are in it. */
    fun export(
        ctx: Context, folder: Uri, entries: List<LogoEntry>, learned: Map<String, List<Fingerprint>>
    ): Pair<File, Int> {
        val files = FolderScanner.listImages(ctx, folder).associateBy { it.uri.toString() }
        val dir = File(ctx.cacheDir, "shared").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val rows = entries.mapNotNull { e -> files[e.uri]?.let { f -> e to f } }
        val out = File(dir, "Logo Finder library (${rows.size} logos).k2lib")
        DataOutputStream(BufferedOutputStream(GZIPOutputStream(FileOutputStream(out)), 1 shl 16)).use { o ->
            o.writeUTF(MAGIC)
            o.writeInt(FORMAT)
            o.writeInt(ENGINE)
            o.writeInt(rows.size)
            for ((e, f) in rows) {
                o.writeUTF(f.relPath)
                o.writeUTF(f.name)
                o.writeLong(f.size)
                IndexStore.writeFp(o, e.fp)
                val l = learned[e.uri] ?: emptyList()
                o.writeInt(l.size)
                l.forEach { IndexStore.writeFp(o, it) }
            }
        }
        return out to rows.size
    }

    /**
     * Checks a received file and keeps a copy until the folder is chosen.
     * Returns the number of logos in it, or an error message.
     */
    fun importFile(ctx: Context, uri: Uri): Result<Int> = runCatching {
        val tmp = File(ctx.filesDir, "$SEED_FILE.tmp")
        val input = ctx.contentResolver.openInputStream(uri) ?: error("The file could not be opened.")
        input.use { i -> FileOutputStream(tmp).use { i.copyTo(it, 1 shl 16) } }
        val seed = try {
            read(tmp)
        } catch (e: IllegalStateException) {
            tmp.delete(); throw e
        } catch (e: Exception) {
            tmp.delete(); error("This is not a Logo Finder library file.")
        }
        tmp.renameTo(File(ctx.filesDir, SEED_FILE))
        seed.count
    }

    fun hasSeed(ctx: Context) = File(ctx.filesDir, SEED_FILE).exists()

    fun seedCount(ctx: Context): Int = try {
        read(File(ctx.filesDir, SEED_FILE)).count
    } catch (e: Exception) {
        0
    }

    fun loadSeed(ctx: Context): Seed? {
        val f = File(ctx.filesDir, SEED_FILE)
        if (!f.exists()) return null
        return try { read(f) } catch (e: Exception) { null }
    }

    fun clearSeed(ctx: Context) {
        File(ctx.filesDir, SEED_FILE).delete()
    }

    private fun read(file: File): Seed =
        DataInputStream(BufferedInputStream(GZIPInputStream(FileInputStream(file)), 1 shl 16)).use { i ->
            check(i.readUTF() == MAGIC) { "This is not a Logo Finder library file." }
            check(i.readInt() == FORMAT) { "This library file is from a different version of Logo Finder. Update both phones." }
            check(i.readInt() == ENGINE) { "This library file is from a different version of Logo Finder. Update both phones." }
            Seed(List(i.readInt()) {
                val relPath = i.readUTF()
                val name = i.readUTF()
                val size = i.readLong()
                val fp = IndexStore.readFp(i)
                val learned = List(i.readInt()) { IndexStore.readFp(i) }
                SeedEntry(relPath, name, size, fp, learned)
            })
        }
}
