@file:OptIn(ExperimentalMaterial3Api::class)

package com.k2.logofinder

import android.text.format.DateUtils
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp

/** Your logo library: folder, count, reading progress, and controls. */
@Composable
fun LibrarySheet(
    vm: MainViewModel,
    onDismiss: () -> Unit,
    onCheckNew: () -> Unit,
    onChangeFolder: () -> Unit,
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surfaceContainerLow
    ) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Your logo library", style = MaterialTheme.typography.headlineSmall)

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) { Icon(AppIcons.Folder, null, tint = MaterialTheme.colorScheme.onPrimaryContainer) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(vm.folderName ?: "No folder chosen", style = MaterialTheme.typography.titleMedium)
                    Text(
                        buildString {
                            append("%,d logos".format(vm.entries.size))
                            if (vm.lastUpdated > 0 && !vm.reading) {
                                append(", updated ")
                                append(DateUtils.getRelativeTimeSpanString(vm.lastUpdated).toString().lowercase())
                            }
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (vm.reading) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        if (vm.readTotal > 0) "Reading %,d of %,d".format(vm.readDone, vm.readTotal) else "Getting ready…",
                        style = MaterialTheme.typography.titleSmall
                    )
                    if (vm.readTotal > 0) {
                        LinearProgressIndicator(
                            progress = { vm.readDone.toFloat() / vm.readTotal }, color = threadColor,
                            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(50))
                        )
                    } else {
                        LinearProgressIndicator(color = threadColor, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(50)))
                    }
                    Text(
                        "Runs in the background, even with the screen off. Progress is also in the notification.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                OutlinedButton(
                    onClick = { vm.stopIndexing() },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) { Text("Stop reading") }
            } else {
                Text(vm.status, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (vm.folderUri != null) {
                    Button(
                        onClick = onCheckNew,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().height(52.dp)
                    ) {
                        Icon(AppIcons.Refresh, null, Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Check for new logos")
                    }
                }
                OutlinedButton(
                    onClick = onChangeFolder,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) { Text(if (vm.folderUri == null) "Choose logo folder" else "Change folder") }
            }
            BatteryTip()
        }
    }
}
