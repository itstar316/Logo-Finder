package com.k2.logofinder

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract

/** A picture in your logo folder. [relPath] is its place inside the folder, e.g. "Sports/Football logo.png". */
class ImageFile(val uri: Uri, val name: String, val modified: Long, val relPath: String, val size: Long)

object FolderScanner {
    /** Lists all pictures in the folder and its subfolders, quickly (one query per folder). */
    fun listImages(ctx: Context, tree: Uri): List<ImageFile> {
        val out = mutableListOf<ImageFile>()
        val columns = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
            DocumentsContract.Document.COLUMN_SIZE
        )
        fun walk(docId: String, prefix: String) {
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            ctx.contentResolver.query(children, columns, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0) ?: continue
                    val name = c.getString(1) ?: ""
                    val mime = c.getString(2) ?: ""
                    val modified = if (c.isNull(3)) 0L else c.getLong(3)
                    val size = if (c.isNull(4)) 0L else c.getLong(4)
                    when {
                        mime == DocumentsContract.Document.MIME_TYPE_DIR -> walk(id, "$prefix$name/")
                        mime.startsWith("image/") -> out += ImageFile(
                            DocumentsContract.buildDocumentUriUsingTree(tree, id), name, modified, "$prefix$name", size
                        )
                    }
                }
            }
        }
        walk(DocumentsContract.getTreeDocumentId(tree), "")
        return out
    }
}
