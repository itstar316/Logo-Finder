package com.k2.logofinder

import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * A compact fingerprint vector: 1 byte per number instead of 4, with its own scale.
 * Makes 6,000+ logos use about 4x less memory and storage, with practically no loss in accuracy.
 */
class Vec(val q: ByteArray, val scale: Float) {

    /** Cosine similarity (vectors are length-normalised before packing). */
    fun dot(other: Vec): Float {
        if (q.size != other.q.size) return -1f
        val a = q
        val b = other.q
        var s = 0
        for (i in a.indices) s += a[i] * b[i]
        return s * scale * other.scale
    }

    companion object {
        fun of(v: FloatArray): Vec {
            var maxAbs = 0f
            for (x in v) if (abs(x) > maxAbs) maxAbs = abs(x)
            if (maxAbs == 0f) return Vec(ByteArray(v.size), 0f)
            val scale = maxAbs / 127f
            return Vec(ByteArray(v.size) { (v[it] / scale).roundToInt().coerceIn(-127, 127).toByte() }, scale)
        }
    }
}
