package com.k2.logofinder

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import java.io.Closeable
import java.io.File
import java.io.FileOutputStream
import java.nio.FloatBuffer
import kotlin.math.sqrt

/**
 * Meta's DINOv2 model, run with ONNX Runtime on the phone.
 * It is very good at "same design, different picture quality" matching.
 * The fingerprint combines the overall summary (CLS) with the average of all image patches.
 */
class DinoEmbedder(context: Context) : Closeable {

    private val env = OrtEnvironment.getEnvironment()
    private val session: OrtSession
    private val inputName: String

    init {
        val file = File(context.filesDir, MODEL_FILE)
        val assetSize = try {
            context.assets.openFd(MODEL_FILE).use { it.length }
        } catch (e: Exception) {
            -1L
        }
        // Copy the model out of the APK once (and again after an app update changes it).
        if (!file.exists() || (assetSize > 0 && file.length() != assetSize)) {
            context.assets.open(MODEL_FILE).use { input ->
                FileOutputStream(file).use { output -> input.copyTo(output, 1 shl 16) }
            }
        }
        val options = OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(Runtime.getRuntime().availableProcessors().coerceIn(1, 4))
        }
        session = env.createSession(file.absolutePath, options)
        inputName = session.inputNames.first()
    }

    @Synchronized
    fun embed(bmp: Bitmap): FloatArray {
        val s = SIZE
        val scaled = Bitmap.createScaledBitmap(bmp, s, s, true)
        val px = IntArray(s * s)
        scaled.getPixels(px, 0, s, 0, 0, s, s)
        val plane = s * s
        val data = FloatArray(3 * plane)
        for (i in 0 until plane) {
            val p = px[i]
            data[i] = (Color.red(p) / 255f - MEAN[0]) / STD[0]
            data[plane + i] = (Color.green(p) / 255f - MEAN[1]) / STD[1]
            data[2 * plane + i] = (Color.blue(p) / 255f - MEAN[2]) / STD[2]
        }
        OnnxTensor.createTensor(env, FloatBuffer.wrap(data), longArrayOf(1, 3, s.toLong(), s.toLong())).use { tensor ->
            session.run(mapOf(inputName to tensor)).use { result ->
                // Prefer the full token output (1 x tokens x 384); fall back to a pooled output.
                for (entry in result) {
                    val v = entry.value.value
                    if (v is Array<*> && v.firstOrNull() is Array<*>) {
                        @Suppress("UNCHECKED_CAST")
                        val tokens = (v as Array<Array<FloatArray>>)[0]
                        return fromTokens(tokens)
                    }
                }
                for (entry in result) {
                    val v = entry.value.value
                    if (v is Array<*> && v.firstOrNull() is FloatArray) {
                        return normalize((v[0] as FloatArray).copyOf())
                    }
                }
            }
        }
        error("DINOv2 model returned no usable output")
    }

    private fun fromTokens(tokens: Array<FloatArray>): FloatArray {
        val dim = tokens[0].size
        val cls = normalize(tokens[0].copyOf())
        val mean = FloatArray(dim)
        for (t in 1 until tokens.size) {
            val row = tokens[t]
            for (d in 0 until dim) mean[d] += row[d]
        }
        normalize(mean)
        val out = FloatArray(dim * 2)
        System.arraycopy(cls, 0, out, 0, dim)
        System.arraycopy(mean, 0, out, dim, dim)
        return normalize(out)
    }

    private fun normalize(v: FloatArray): FloatArray {
        var sum = 0f
        for (x in v) sum += x * x
        val n = sqrt(sum)
        if (n > 0f) for (i in v.indices) v[i] /= n
        return v
    }

    override fun close() {
        session.close()
    }

    companion object {
        const val MODEL_FILE = "dinov2_small.onnx"
        private const val SIZE = 224
        private val MEAN = floatArrayOf(0.485f, 0.456f, 0.406f)
        private val STD = floatArrayOf(0.229f, 0.224f, 0.225f)
    }
}
