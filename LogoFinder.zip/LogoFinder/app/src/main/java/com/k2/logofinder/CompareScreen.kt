package com.k2.logofinder

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

/** The client's picture above, your file below, both zoomable, so you can be sure before copying. */
@Composable
fun CompareScreen(
    match: Match,
    clientPicture: Bitmap?,
    onBack: () -> Unit,
    onConfirm: () -> Unit,
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(AppIcons.Back, "Back") }
            Text("Compare", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
        }

        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (clientPicture != null) {
                Panel("Client’s picture", Modifier.weight(1f)) {
                    Image(
                        clientPicture.asImageBitmap(), "Client's picture",
                        contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize()
                    )
                }
            }
            Panel("Your file", Modifier.weight(1f), white = true) {
                LogoImage(match.entry.uri, match.entry.name, Modifier.fillMaxSize(), padding = 12.dp)
            }
        }

        Text(
            "Pinch or double-tap to zoom",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 8.dp)
        )
        Spacer(Modifier.height(12.dp))
        Text(match.entry.name, style = MaterialTheme.typography.headlineSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
        if (match.fromLearned) {
            Text(
                "You confirmed this client picture before.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = onConfirm,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) {
            Icon(AppIcons.Check, null)
            Spacer(Modifier.width(10.dp))
            Text(if (clientPicture != null) "This is it, copy name" else "Copy name", style = MaterialTheme.typography.titleMedium)
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = onBack,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text(if (clientPicture != null) "Not this one" else "Back") }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun Panel(label: String, modifier: Modifier, white: Boolean = false, content: @Composable () -> Unit) {
    Box(
        modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
            .background(if (white) Color.White else MaterialTheme.colorScheme.surfaceContainerHigh)
    ) {
        Zoomable(Modifier.fillMaxSize()) { content() }
        Pill(label, Color.Black.copy(alpha = 0.6f), Color.White, Modifier.align(Alignment.TopStart).padding(10.dp))
    }
}
