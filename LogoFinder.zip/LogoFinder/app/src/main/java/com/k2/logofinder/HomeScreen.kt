package com.k2.logofinder

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridScope
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

@Composable
fun HomeScreen(
    vm: MainViewModel,
    nameQuery: String,
    onNameQuery: (String) -> Unit,
    onPickPicture: () -> Unit,
    onChooseFolder: () -> Unit,
    onOpenLibrary: () -> Unit,
    onCompare: (Match) -> Unit,
    onCopy: (String) -> Unit,
) {
    val hasLogos = vm.entries.isNotEmpty()
    val nameResults = remember(nameQuery, vm.entries) {
        if (nameQuery.isBlank()) emptyList()
        else vm.entries.filter { it.name.contains(nameQuery.trim(), ignoreCase = true) }.take(200)
    }

    LazyVerticalGrid(
        columns = GridCells.Adaptive(156.dp),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 32.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        full { TopBar(vm, onOpenLibrary) }

        if (vm.reading) full { ReadingBanner(vm, onOpenLibrary) }

        if (!hasLogos && !vm.reading) {
            full { Onboarding(onChooseFolder) }
            return@LazyVerticalGrid
        }

        full {
            Column(Modifier.padding(top = 12.dp, bottom = 4.dp)) {
                Text("Find a logo", style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Use the picture your client sent. Blurry photos are fine.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        full { SearchTarget(enabled = hasLogos, onClick = onPickPicture) }

        full {
            OutlinedTextField(
                value = nameQuery,
                onValueChange = onNameQuery,
                placeholder = { Text("Search by file name") },
                leadingIcon = { Icon(AppIcons.Search, contentDescription = null) },
                trailingIcon = {
                    if (nameQuery.isNotEmpty()) {
                        IconButton(onClick = { onNameQuery("") }) { Icon(AppIcons.Close, "Clear") }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (nameQuery.isNotBlank()) {
            full {
                Text(
                    if (nameResults.isEmpty()) "No file names contain “${nameQuery.trim()}”."
                    else "${nameResults.size}${if (nameResults.size == 200) "+" else ""} files",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            items(nameResults, key = { it.uri }) { e ->
                val m = remember(e) { Match(e, 0f, 0f, 0f, false) }
                MatchCard(rank = null, match = m, onClick = { onCompare(m) }, onCopy = { onCopy(e.name) })
            }
        } else if (vm.recents.isNotEmpty()) {
            full {
                Column(Modifier.padding(top = 12.dp)) {
                    Text("Recently found", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Tap to copy the name again",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(10.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(vm.recents, key = { it.time }) { r -> RecentCard(r) { onCopy(r.name) } }
                    }
                }
            }
        }
    }
}

/** Adds a row that spans the whole width of the grid. */
fun LazyGridScope.full(content: @Composable () -> Unit) {
    item(span = { GridItemSpan(maxLineSpan) }) { content() }
}

@Composable
private fun TopBar(vm: MainViewModel, onOpenLibrary: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Logo Finder", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
        val (dot, label) = when {
            vm.reading -> threadColor to (if (vm.readTotal > 0) "Reading ${percent(vm)}" else "Reading")
            vm.entries.isNotEmpty() -> Palette.Ready to "%,d logos".format(vm.entries.size)
            else -> MaterialTheme.colorScheme.outline to "Set up"
        }
        Surface(
            onClick = onOpenLibrary,
            shape = RoundedCornerShape(50),
            color = MaterialTheme.colorScheme.surfaceContainerLow,
            border = CardDefaults.outlinedCardBorder()
        ) {
            Row(
                Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatusDot(dot)
                Text(label, style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}

fun percent(vm: MainViewModel): String =
    if (vm.readTotal == 0) "" else "${(vm.readDone * 100 / vm.readTotal)}%"

@Composable
private fun ReadingBanner(vm: MainViewModel, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.secondaryContainer,
        contentColor = MaterialTheme.colorScheme.onSecondaryContainer
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                if (vm.readTotal > 0) "Reading logos: %,d of %,d".format(vm.readDone, vm.readTotal)
                else "Getting your logos ready…",
                style = MaterialTheme.typography.titleSmall
            )
            if (vm.readTotal > 0) {
                LinearProgressIndicator(
                    progress = { vm.readDone.toFloat() / vm.readTotal },
                    color = threadColor,
                    trackColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(50))
                )
            } else {
                LinearProgressIndicator(color = threadColor, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(50)))
            }
            Text(
                IndexWorker.timeLeftText(vm.readDone, vm.readMinutesLeft).removePrefix(", ").removePrefix("…")
                    .replaceFirstChar { it.uppercase() }
                    .ifBlank { "Runs in the background. You can search logos that are already read." },
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun SearchTarget(enabled: Boolean, onClick: () -> Unit) {
    val thread = threadColor
    Surface(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        modifier = Modifier.fillMaxWidth().stitched(thread)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier.size(64.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center
            ) {
                Icon(AppIcons.Photo, null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(30.dp))
            }
            Spacer(Modifier.height(16.dp))
            Text("Choose the client’s picture", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(6.dp))
            Text(
                "Or open it in Gmail or WhatsApp, tap Share, and pick Logo Finder.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}

@Composable
private fun Onboarding(onChooseFolder: () -> Unit) {
    Column(Modifier.padding(top = 24.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        Text("Find any logo you’ve digitized, from the client’s picture.", style = MaterialTheme.typography.headlineSmall)
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                Step(1, "Copy your Wilcom pictures to a folder on this phone", "Subfolders are fine. File names are shown in results.")
                Step(2, "Choose that folder", "The app reads every logo once, in the background. About 1–3 hours for 6,000.")
                Step(3, "Search with the client’s picture", "Tap the right match to copy its name, then paste it in Gmail.")
            }
        }
        Button(
            onClick = onChooseFolder,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) {
            Icon(AppIcons.Folder, null)
            Spacer(Modifier.width(10.dp))
            Text("Choose logo folder", style = MaterialTheme.typography.titleMedium)
        }
        BatteryTip()
    }
}

@Composable
private fun Step(n: Int, title: String, detail: String) {
    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(
            Modifier.size(28.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Text("$n", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
        }
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun BatteryTip() {
    Text(
        "On Xiaomi, Redmi, Oppo, Vivo, Realme, Infinix or Tecno phones, set Settings → Apps → Logo Finder → Battery to “No restrictions” so reading isn’t stopped.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
private fun RecentCard(r: Recent, onClick: () -> Unit) {
    val bmp = remember(r.thumbPath) { BitmapFactory.decodeFile(r.thumbPath)?.asImageBitmap() }
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        modifier = Modifier.width(140.dp)
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(1.25f).background(MaterialTheme.colorScheme.surfaceContainerHigh)) {
            if (bmp != null) {
                Image(bmp, "Client's picture", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            }
        }
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                r.name, style = MaterialTheme.typography.labelLarge, maxLines = 1,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
            )
            Icon(AppIcons.Copy, "Copy name", Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/** A logo in a results grid: picture, name, rank, and a one-tap copy button. */
@Composable
fun MatchCard(rank: Int?, match: Match, onClick: () -> Unit, onCopy: () -> Unit) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Box {
            LogoImage(match.entry.uri, match.entry.name, Modifier.fillMaxWidth().aspectRatio(1f))
            if (rank != null) {
                Pill(
                    "$rank", MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.onPrimary,
                    Modifier.align(Alignment.TopStart).padding(8.dp)
                )
            }
            if (match.fromLearned) {
                Pill(
                    "Seen before", threadColor, Color.White,
                    Modifier.align(Alignment.TopEnd).padding(8.dp)
                )
            }
        }
        Row(Modifier.padding(start = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                match.entry.name, style = MaterialTheme.typography.bodyMedium, maxLines = 2,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(vertical = 10.dp)
            )
            IconButton(onClick = onCopy) {
                Icon(AppIcons.Copy, "Copy name", Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
