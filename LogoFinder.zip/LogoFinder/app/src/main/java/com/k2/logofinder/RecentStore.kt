package com.k2.logofinder

import android.content.Context
import android.graphics.Bitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/** A logo you confirmed recently, with a small copy of the client's picture. */
class Recent(val name: String, val logoUri: String, val thumbPath: String, val time: Long)

/** "Recently found" list on the home screen, so repeat requests take one tap. */
object RecentStore {
    private const val FILE = "recents.json"
    private const val MAX = 30

    fun load(ctx: Context): List<Recent> = try {
        val arr = JSONArray(File(ctx.filesDir, FILE).readText())
        List(arr.length()) {
            val o = arr.getJSONObject(it)
            Recent(o.getString("name"), o.getString("uri"), o.getString("thumb"), o.getLong("time"))
        }.filter { File(it.thumbPath).exists() }
    } catch (e: Exception) {
        emptyList()
    }

    fun add(ctx: Context, current: List<Recent>, name: String, logoUri: String, clientPicture: Bitmap): List<Recent> {
        val dir = File(ctx.filesDir, "recents").apply { mkdirs() }
        val time = System.currentTimeMillis()
        val thumb = File(dir, "$time.jpg")
        FileOutputStream(thumb).use { Images.fitInside(clientPicture, 360).compress(Bitmap.CompressFormat.JPEG, 85, it) }

        val updated = (listOf(Recent(name, logoUri, thumb.absolutePath, time)) +
            current.filter { it.logoUri != logoUri }).take(MAX)
        val keep = updated.map { it.thumbPath }.toSet()
        current.filter { it.thumbPath !in keep }.forEach { File(it.thumbPath).delete() }

        val arr = JSONArray()
        updated.forEach {
            arr.put(JSONObject().put("name", it.name).put("uri", it.logoUri).put("thumb", it.thumbPath).put("time", it.time))
        }
        File(ctx.filesDir, FILE).writeText(arr.toString())
        return updated
    }
}
