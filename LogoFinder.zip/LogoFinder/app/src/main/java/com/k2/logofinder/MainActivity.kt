package com.k2.logofinder

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.core.content.IntentCompat
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) handleShare(intent)
        setContent {
            LogoFinderTheme { LogoFinderApp(vm) }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    /** Lets you tap "Share" on a picture in Gmail or WhatsApp and pick Logo Finder. */
    private fun handleShare(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND && intent.type?.startsWith("image/") == true) {
            IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)?.let(vm::search)
        }
    }
}

private enum class Screen { HOME, RESULTS, CROP, COMPARE }

@Composable
fun LogoFinderApp(vm: MainViewModel) {
    val ctx = LocalContext.current
    val haptics = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    var cropping by remember { mutableStateOf(false) }
    var comparing by remember { mutableStateOf<Match?>(null) }
    // Keeps the compare screen drawn while it animates away.
    var lastCompared by remember { mutableStateOf<Match?>(null) }
    if (comparing != null) lastCompared = comparing
    var showLibrary by remember { mutableStateOf(false) }
    var nameQuery by rememberSaveable { mutableStateOf("") }

    val screen = when {
        cropping && vm.queryBitmap != null -> Screen.CROP
        comparing != null -> Screen.COMPARE
        vm.searchedBitmap != null -> Screen.RESULTS
        else -> Screen.HOME
    }

    BackHandler(enabled = screen != Screen.HOME) {
        when (screen) {
            Screen.CROP -> cropping = false
            Screen.COMPARE -> comparing = null
            Screen.RESULTS -> vm.clearSearch()
            Screen.HOME -> Unit
        }
    }

    // Copy a name, confirm with a vibration, and offer to open Gmail.
    fun copyName(name: String) {
        ctx.getSystemService(ClipboardManager::class.java)
            .setPrimaryClip(ClipData.newPlainText("Logo name", name))
        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            val gmail = gmailIntent(ctx)
            val result = snackbar.showSnackbar(
                message = "Copied “$name”",
                actionLabel = if (gmail != null) "Open Gmail" else null,
                duration = SnackbarDuration.Long
            )
            if (result == SnackbarResult.ActionPerformed && gmail != null) ctx.startActivity(gmail)
        }
    }

    fun confirm(m: Match) {
        vm.confirm(m)
        copyName(m.entry.name)
        comparing = null
    }

    // Reading permissions: notifications (Android 13+) so progress can be shown, then start.
    var pendingFolder by remember { mutableStateOf<Uri?>(null) }
    val askNotifications = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        vm.indexFolder(pendingFolder)
    }
    fun startReading(folder: Uri?) {
        val target = folder ?: vm.folderUri
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pendingFolder = target
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            vm.indexFolder(target)
        }
    }
    val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            showLibrary = false
            startReading(uri)
        }
    }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let { nameQuery = ""; vm.search(it) }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        containerColor = MaterialTheme.colorScheme.background
    ) { insets ->
        Box(Modifier.fillMaxSize().padding(insets)) {
            AnimatedContent(
                targetState = screen,
                transitionSpec = {
                    val forward = targetState.ordinal > initialState.ordinal
                    val dir = if (forward) 1 else -1
                    (slideInHorizontally(tween(260)) { it / 8 * dir } + fadeIn(tween(260))) togetherWith
                        (slideOutHorizontally(tween(200)) { -it / 8 * dir } + fadeOut(tween(200)))
                },
                label = "screens"
            ) { s ->
                when (s) {
                    Screen.HOME -> HomeScreen(
                        vm = vm,
                        nameQuery = nameQuery,
                        onNameQuery = { nameQuery = it },
                        onPickPicture = {
                            pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        },
                        onChooseFolder = { pickFolder.launch(null) },
                        onOpenLibrary = { showLibrary = true },
                        onCompare = { comparing = it },
                        onCopy = ::copyName
                    )
                    Screen.RESULTS -> ResultsScreen(
                        vm = vm,
                        onBack = { vm.clearSearch() },
                        onCrop = { cropping = true },
                        onCompare = { comparing = it },
                        onConfirm = ::confirm,
                        onCopy = ::copyName
                    )
                    Screen.CROP -> vm.queryBitmap?.let { bmp ->
                        CropScreen(
                            bitmap = bmp,
                            onCancel = { cropping = false },
                            onCrop = { part ->
                                cropping = false
                                vm.searchCropped(part)
                            }
                        )
                    }
                    Screen.COMPARE -> lastCompared?.let { m ->
                        val fromSearch = vm.searchedBitmap != null
                        CompareScreen(
                            match = m,
                            clientPicture = if (fromSearch) vm.searchedBitmap else null,
                            onBack = { comparing = null },
                            onConfirm = {
                                if (fromSearch) confirm(m) else { copyName(m.entry.name); comparing = null }
                            }
                        )
                    }
                }
            }
        }
    }

    if (showLibrary) {
        LibrarySheet(
            vm = vm,
            onDismiss = { showLibrary = false },
            onCheckNew = { showLibrary = false; startReading(null) },
            onChangeFolder = { pickFolder.launch(null) }
        )
    }
}

private fun gmailIntent(ctx: Context): Intent? =
    ctx.packageManager.getLaunchIntentForPackage("com.google.android.gm")
