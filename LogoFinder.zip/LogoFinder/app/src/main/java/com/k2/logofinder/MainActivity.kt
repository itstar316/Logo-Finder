package com.k2.logofinder

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.IntentCompat
import coil.compose.AsyncImage

private val Navy = Color(0xFF1F2A44)
private val Thread = Color(0xFFC9A227)
private val Fabric = Color(0xFFF3F5F8)

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) handleShare(intent)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Navy, onPrimary = Color.White,
                    secondary = Thread, background = Fabric, surface = Color.White
                )
            ) {
                Surface(Modifier.fillMaxSize(), color = Fabric) { LogoFinderApp(vm) }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    /** Lets you tap "Share" on a picture in Gmail or WhatsApp and pick Logo Finder. */
    private fun handleShare(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND && intent.type?.startsWith("image/") == true) {
            IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)?.let(vm::search)
        }
    }
}

@Composable
fun LogoFinderApp(vm: MainViewModel) {
    var cropping by remember { mutableStateOf(false) }
    val query = vm.queryBitmap

    // Keep the screen on while logos are being read.
    val view = LocalView.current
    val indexing = vm.progress != null
    DisposableEffect(indexing) {
        view.keepScreenOn = indexing
        onDispose { view.keepScreenOn = false }
    }

    BackHandler(enabled = cropping) { cropping = false }

    Box(Modifier.fillMaxSize().safeDrawingPadding()) {
        if (cropping && query != null) {
            CropScreen(
                bitmap = query,
                onCancel = { cropping = false },
                onCrop = { part ->
                    cropping = false
                    vm.searchCropped(part)
                }
            )
        } else {
            MainScreen(vm, onCrop = { cropping = true })
        }
    }
}

@Composable
private fun MainScreen(vm: MainViewModel, onCrop: () -> Unit) {
    val ctx = LocalContext.current
    var selected by remember { mutableStateOf<Match?>(null) }
    var nameFilter by remember { mutableStateOf("") }

    val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            vm.indexFolder(uri)
        }
    }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let { nameFilter = ""; vm.search(it) }
    }

    val shown: List<Match> =
        if (nameFilter.isBlank()) vm.results
        else vm.entries.filter { it.name.contains(nameFilter.trim(), ignoreCase = true) }
            .take(200).map { Match(it, 0f, 0f, 0f, false) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Logo Finder", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Navy)
        Spacer(Modifier.height(12.dp))

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(vm.status, style = MaterialTheme.typography.bodyLarge)
                vm.progress?.let { p ->
                    LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth(), color = Thread)
                    Text(
                        "Keep the app open and the phone charging. You can stop and continue later.",
                        style = MaterialTheme.typography.bodySmall, color = Color.Gray
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (vm.progress != null) {
                        OutlinedButton(onClick = { vm.stopIndexing() }) { Text("Stop") }
                    } else {
                        OutlinedButton(onClick = { pickFolder.launch(null) }) {
                            Text(if (vm.folderUri == null) "Choose logo folder" else "Change folder")
                        }
                        if (vm.folderUri != null) {
                            TextButton(onClick = { vm.indexFolder() }) { Text("Check for new logos") }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
            enabled = vm.entries.isNotEmpty() && !vm.searching,
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) { Text("Search with client's picture", style = MaterialTheme.typography.titleMedium) }

        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = nameFilter,
            onValueChange = { nameFilter = it },
            label = { Text("Or search by name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        if (nameFilter.isBlank()) {
            vm.searchedBitmap?.let { bmp ->
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        bmp.asImageBitmap(), contentDescription = "Client's picture",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.size(64.dp).clip(RoundedCornerShape(10.dp))
                    )
                    Spacer(Modifier.size(12.dp))
                    Column(Modifier.weight(1f)) {
                        if (vm.searching) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.size(8.dp))
                                Text("Searching…")
                            }
                        } else {
                            Text("Best matches first. Tap the right one.")
                            if (vm.queryWords.isNotEmpty()) {
                                Text(
                                    "Words read: " + vm.queryWords.joinToString(" "),
                                    style = MaterialTheme.typography.bodySmall, color = Color.Gray,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                    if (!vm.searching && vm.queryBitmap != null) {
                        TextButton(onClick = onCrop) { Text("Crop") }
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(
            columns = GridCells.Adaptive(150.dp),
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            itemsIndexed(shown, key = { _, m -> m.entry.uri }) { i, m ->
                ResultCard(if (nameFilter.isBlank()) i + 1 else null, m) { selected = m }
            }
        }
    }

    selected?.let { m ->
        val fromSearch = nameFilter.isBlank()
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text(m.entry.name) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (fromSearch) {
                            vm.searchedBitmap?.let {
                                Image(
                                    it.asImageBitmap(), "Client's picture", contentScale = ContentScale.Fit,
                                    modifier = Modifier.weight(1f).aspectRatio(1f).background(Color.White)
                                )
                            }
                        }
                        AsyncImage(
                            model = Uri.parse(m.entry.uri), contentDescription = m.entry.name,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.weight(1f).aspectRatio(1f).background(Color.White)
                        )
                    }
                    if (fromSearch) {
                        Text(
                            "Picture match %.2f, words match %.2f".format(m.visual, m.text) +
                                if (m.fromLearned) ". Matched a client photo you confirmed before." else "",
                            style = MaterialTheme.typography.bodySmall, color = Color.Gray
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val cm = ctx.getSystemService(ClipboardManager::class.java)
                    cm.setPrimaryClip(ClipData.newPlainText("Logo name", m.entry.name))
                    if (fromSearch) vm.confirm(m)
                    Toast.makeText(ctx, "Copied: ${m.entry.name}", Toast.LENGTH_SHORT).show()
                    selected = null
                }) { Text(if (fromSearch) "This is it, copy name" else "Copy name") }
            },
            dismissButton = { TextButton(onClick = { selected = null }) { Text("Close") } }
        )
    }
}

@Composable
private fun ResultCard(rank: Int?, m: Match, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Box {
            AsyncImage(
                model = Uri.parse(m.entry.uri), contentDescription = m.entry.name,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxWidth().aspectRatio(1f).background(Color.White).padding(6.dp)
            )
            if (rank != null) {
                Text(
                    "$rank",
                    color = Color.White,
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.align(Alignment.TopStart).padding(6.dp)
                        .background(if (rank == 1) Thread else Navy, RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                )
            }
        }
        Text(
            m.entry.name, maxLines = 2, overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(8.dp)
        )
    }
}
