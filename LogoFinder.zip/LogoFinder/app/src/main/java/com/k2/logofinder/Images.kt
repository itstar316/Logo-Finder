package com.k2.logofinder

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Loading and cleaning up pictures before the AI models see them. */
object Images {

    /** Loads a picture at a manageable size, fixes phone-photo rotation, and puts transparency on white. */
    fun load(cr: ContentResolver, uri: Uri, maxSide: Int): Bitmap? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            null
        } else {
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
            val opts = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            val raw = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            raw?.let { fitInside(onWhite(rotateByExif(cr, uri, it)), maxSide) }
        }
    } catch (e: Exception) {
        null
    } catch (e: OutOfMemoryError) {
        null
    }

    private fun rotateByExif(cr: ContentResolver, uri: Uri, bmp: Bitmap): Bitmap {
        val degrees = try {
            cr.openInputStream(uri)?.use { stream ->
                when (ExifInterface(stream).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                )) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (e: Exception) {
            0f
        }
        if (degrees == 0f) return bmp
        val m = Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }

    fun fitInside(bmp: Bitmap, maxSide: Int): Bitmap {
        val largest = max(bmp.width, bmp.height)
        if (largest <= maxSide) return bmp
        val scale = maxSide.toFloat() / largest
        return Bitmap.createScaledBitmap(
            bmp,
            (bmp.width * scale).roundToInt().coerceAtLeast(1),
            (bmp.height * scale).roundToInt().coerceAtLeast(1),
            true
        )
    }

    /** Enlarges small pictures so the text reader can see small letters. */
    fun upscaleForText(bmp: Bitmap, targetSide: Int = 2000): Bitmap {
        val largest = max(bmp.width, bmp.height)
        if (largest >= targetSide) return bmp
        val scale = min(targetSide.toFloat() / largest, 3f)
        return Bitmap.createScaledBitmap(
            bmp, (bmp.width * scale).roundToInt(), (bmp.height * scale).roundToInt(), true
        )
    }

    /** Wilcom exports are often transparent PNGs; flatten them onto white. */
    fun onWhite(src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        Canvas(out).apply {
            drawColor(Color.WHITE)
            drawBitmap(src, 0f, 0f, null)
        }
        return out
    }

    /** Black-and-white copy, so thread colours vs. original colours matter less. */
    fun gray(src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val paint = Paint().apply {
            colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) })
        }
        Canvas(out).drawBitmap(src, 0f, 0f, paint)
        return out
    }

    /**
     * Stretches brightness so the darkest 1% becomes black and the brightest 1% becomes white.
     * Dull, dark client photos become clear; clean Wilcom images barely change.
     */
    fun autoContrast(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val hist = IntArray(256)
        for (p in px) hist[luma(p)]++
        val cut = px.size / 100
        var lo = 0; var acc = 0
        while (lo < 255 && acc + hist[lo] <= cut) { acc += hist[lo]; lo++ }
        var hi = 255; acc = 0
        while (hi > 0 && acc + hist[hi] <= cut) { acc += hist[hi]; hi-- }
        if (hi - lo < 20 || (lo <= 3 && hi >= 252)) return src
        val lut = IntArray(256) { ((it - lo) * 255f / (hi - lo)).roundToInt().coerceIn(0, 255) }
        for (i in px.indices) {
            val p = px[i]
            px[i] = Color.rgb(lut[Color.red(p)], lut[Color.green(p)], lut[Color.blue(p)])
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    /** Cuts away empty plain background around the logo (big plain margins in exports). */
    fun trimBackground(src: Bitmap, tolerance: Int = 45): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val bg = px[0]
        var minX = w; var minY = h; var maxX = -1; var maxY = -1
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                if (colorDiff(px[row + x], bg) > tolerance) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }
        if (maxX < 0) return src
        val bw = maxX - minX + 1
        val bh = maxY - minY + 1
        if (bw < 8 || bh < 8) return src
        val pad = (max(bw, bh) * 0.05f).roundToInt()
        val left = (minX - pad).coerceAtLeast(0)
        val top = (minY - pad).coerceAtLeast(0)
        val right = (maxX + pad).coerceAtMost(w - 1)
        val bottom = (maxY + pad).coerceAtMost(h - 1)
        return Bitmap.createBitmap(src, left, top, right - left + 1, bottom - top + 1)
    }

    /**
     * Makes the picture square by adding background around it, so the models never
     * stretch or cut off a wide logo (like a row of icons with names).
     */
    fun padToSquare(src: Bitmap): Bitmap {
        if (src.width == src.height) return src
        val side = max(src.width, src.height)
        val out = Bitmap.createBitmap(side, side, Bitmap.Config.ARGB_8888)
        Canvas(out).apply {
            drawColor(src.getPixel(0, 0) or 0xFF000000.toInt())
            drawBitmap(src, ((side - src.width) / 2).toFloat(), ((side - src.height) / 2).toFloat(), null)
        }
        return out
    }

    /** Middle part of a photo, for when the logo is small (on a shirt, a sign, etc.). */
    fun centerCrop(src: Bitmap, fraction: Float): Bitmap {
        val w = (src.width * fraction).roundToInt().coerceAtLeast(1)
        val h = (src.height * fraction).roundToInt().coerceAtLeast(1)
        return Bitmap.createBitmap(src, (src.width - w) / 2, (src.height - h) / 2, w, h)
    }

    private fun luma(p: Int): Int =
        ((Color.red(p) * 299 + Color.green(p) * 587 + Color.blue(p) * 114) / 1000).coerceIn(0, 255)

    private fun colorDiff(a: Int, b: Int): Int =
        abs(Color.red(a) - Color.red(b)) + abs(Color.green(a) - Color.green(b)) + abs(Color.blue(a) - Color.blue(b))
}
