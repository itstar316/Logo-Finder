package com.k2.logofinder

import android.content.Context

/** One shared copy of the AI models for the whole app (searching and background reading). */
object Engines {
    private var engine: LogoEngine? = null

    @Synchronized
    fun get(ctx: Context): LogoEngine =
        engine ?: LogoEngine(ctx.applicationContext).also { engine = it }
}
