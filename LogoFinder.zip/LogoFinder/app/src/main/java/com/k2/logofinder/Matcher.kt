package com.k2.logofinder

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class Match(
    val entry: LogoEntry,
    val score: Float,
    val visual: Float,
    val text: Float,
    val fromLearned: Boolean
)

object Matcher {

    private const val DINO_WEIGHT = 0.7f
    private const val MOBILE_WEIGHT = 0.3f
    private const val TEXT_WEIGHT = 0.25f

    fun tokens(text: String): Set<String> =
        text.uppercase().split(Regex("[^A-Z0-9]+")).filter { it.length >= 3 }.toSet()

    /** Compares the client's picture with every logo (and every confirmed client photo) and returns the best first. */
    fun rank(query: Fingerprint, entries: List<LogoEntry>, top: Int): List<Match> =
        entries.map { e ->
            val own = visualScore(query, e.fp)
            var learned = -1f
            for (l in e.learned) learned = max(learned, visualScore(query, l))
            val visual = max(own, learned)
            val words = if (e.learned.isEmpty()) e.fp.words else e.fp.words + e.learned.flatMap { it.words }
            val text = textScore(query.words, words)
            Match(e, visual + TEXT_WEIGHT * text, visual, text, learned > own)
        }.sortedByDescending { it.score }.take(top)

    private fun visualScore(q: Fingerprint, fp: Fingerprint): Float {
        var bestDino = -1f
        var bestMobile = -1f
        for (a in q.views) for (b in fp.views) {
            bestDino = max(bestDino, a.weight * a.dino.dot(b.dino))
            bestMobile = max(bestMobile, a.weight * a.mobile.dot(b.mobile))
        }
        return DINO_WEIGHT * bestDino + MOBILE_WEIGHT * bestMobile
    }

    /** Share of words that match, forgiving small reading mistakes in longer words. */
    private fun textScore(a: Set<String>, b: Set<String>): Float {
        if (a.isEmpty() || b.isEmpty()) return 0f
        val hits = a.count { w -> b.any { similar(w, it) } }
        return (hits.toFloat() / min(a.size, b.size)).coerceAtMost(1f)
    }

    private fun similar(x: String, y: String): Boolean {
        if (x == y) return true
        val shorter = min(x.length, y.length)
        if (shorter < 5 || abs(x.length - y.length) > 2) return false
        val allowed = if (shorter >= 9) 2 else 1
        return editDistance(x, y) <= allowed
    }

    private fun editDistance(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1)
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = min(min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost)
            }
            prev = cur
        }
        return prev[b.length]
    }
}
