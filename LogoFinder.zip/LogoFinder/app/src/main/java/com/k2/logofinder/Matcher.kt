package com.k2.logofinder

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class Match(val entry: LogoEntry, val score: Float, val visual: Float, val text: Float)

object Matcher {

    /** How much matching words count compared to visual likeness. */
    private const val TEXT_WEIGHT = 0.25f

    fun tokens(text: String): Set<String> =
        text.uppercase().split(Regex("[^A-Z0-9]+")).filter { it.length >= 3 }.toSet()

    /** Compares the client's picture with every logo and returns the best ones first. */
    fun rank(query: Fingerprint, entries: List<LogoEntry>, top: Int = 30): List<Match> =
        entries.map { e ->
            var visual = -1f
            for (a in query.views) for (b in e.fp.views) visual = max(visual, dot(a, b))
            val text = textScore(query.words, e.fp.words)
            Match(e, visual + TEXT_WEIGHT * text, visual, text)
        }.sortedByDescending { it.score }.take(top)

    /** Embeddings are L2-normalised, so the dot product is the cosine similarity. */
    private fun dot(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size) return -1f
        var s = 0f
        for (i in a.indices) s += a[i] * b[i]
        return s
    }

    /** Share of words that match, allowing one wrong letter in longer words (OCR mistakes). */
    private fun textScore(a: Set<String>, b: Set<String>): Float {
        if (a.isEmpty() || b.isEmpty()) return 0f
        val hits = a.count { w -> b.any { similar(w, it) } }
        return (hits.toFloat() / min(a.size, b.size)).coerceAtMost(1f)
    }

    private fun similar(x: String, y: String): Boolean =
        x == y || (min(x.length, y.length) >= 5 && abs(x.length - y.length) <= 1 && editDistance(x, y) <= 1)

    private fun editDistance(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1)
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = min(min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost)
            }
            prev = cur
        }
        return prev[b.length]
    }
}
