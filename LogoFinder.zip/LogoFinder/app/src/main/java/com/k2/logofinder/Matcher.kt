package com.k2.logofinder

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class Match(
    val entry: LogoEntry,
    val score: Float,
    val visual: Float,
    val text: Float,
    val fromLearned: Boolean,
    /** Other files that are the same picture (e.g. "2L logo (1)", "2L logo (2)"). */
    val copies: List<LogoEntry> = emptyList()
)

object Matcher {

    private const val DINO_WEIGHT = 0.7f
    private const val MOBILE_WEIGHT = 0.3f
    private const val TEXT_WEIGHT = 0.25f

    fun tokens(text: String): Set<String> =
        text.uppercase().split(Regex("[^A-Z0-9]+")).filter { it.length >= 3 }.toSet()

    /**
     * Compares the client's picture with every logo (and every confirmed client photo) and returns the best first.
     * Files that are the same picture are shown once, with the others listed as copies.
     */
    fun rank(query: Fingerprint, entries: List<LogoEntry>, top: Int): List<Match> {
        val scored = entries.map { e ->
            val own = visualScore(query, e.fp)
            var learned = -1f
            for (l in e.learned) learned = max(learned, visualScore(query, l))
            val visual = max(own, learned)
            val words = if (e.learned.isEmpty()) e.fp.words else e.fp.words + e.learned.flatMap { it.words }
            val text = textScore(query.words, words)
            Match(e, visual + TEXT_WEIGHT * text, visual, text, learned > own)
        }.sortedByDescending { it.score }.take(top * 6)

        // Group identical pictures together.
        val groups = mutableListOf<MutableList<Match>>()
        for (m in scored) {
            val group = groups.firstOrNull { samePicture(it[0].entry, m.entry) }
            if (group != null) group += m
            else if (groups.size < top) groups += mutableListOf(m)
        }
        return groups.map { g ->
            // Show the cleanest name: "2L logo" rather than "2L logo (2)".
            val main = g.minWith(compareBy<Match>({ hasCopyNumber(it.entry.name) }, { it.entry.name.length }))
            val best = g[0]
            Match(
                entry = main.entry,
                score = best.score,
                visual = best.visual,
                text = best.text,
                fromLearned = g.any { it.fromLearned },
                copies = g.filter { it !== main }.map { it.entry }
            )
        }
    }

    private val copyNumber = Regex("""\s*[\(\[\-_]?\s*\d{1,3}\s*[\)\]]$""")
    private fun hasCopyNumber(name: String) = copyNumber.containsMatchIn(name)

    /**
     * True when two files are the same picture: exact copies, or the same image saved again.
     * The threshold is strict, so different colour versions of a design stay separate.
     */
    fun samePicture(a: LogoEntry, b: LogoEntry): Boolean {
        val va = a.fp.views.firstOrNull() ?: return false
        val vb = b.fp.views.firstOrNull() ?: return false
        return va.dino.dot(vb.dino) >= SAME_PICTURE && va.mobile.dot(vb.mobile) >= SAME_PICTURE
    }

    private const val SAME_PICTURE = 0.985f

    private fun visualScore(q: Fingerprint, fp: Fingerprint): Float {
        var bestDino = -1f
        var bestMobile = -1f
        for (a in q.views) for (b in fp.views) {
            bestDino = max(bestDino, a.weight * a.dino.dot(b.dino))
            bestMobile = max(bestMobile, a.weight * a.mobile.dot(b.mobile))
        }
        return DINO_WEIGHT * bestDino + MOBILE_WEIGHT * bestMobile
    }

    /** Share of words that match, forgiving small reading mistakes in longer words. */
    private fun textScore(a: Set<String>, b: Set<String>): Float {
        if (a.isEmpty() || b.isEmpty()) return 0f
        val hits = a.count { w -> b.any { similar(w, it) } }
        return (hits.toFloat() / min(a.size, b.size)).coerceAtMost(1f)
    }

    private fun similar(x: String, y: String): Boolean {
        if (x == y) return true
        val shorter = min(x.length, y.length)
        if (shorter < 5 || abs(x.length - y.length) > 2) return false
        val allowed = if (shorter >= 9) 2 else 1
        return editDistance(x, y) <= allowed
    }

    private fun editDistance(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1)
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = min(min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost)
            }
            prev = cur
        }
        return prev[b.length]
    }
}
