package com.k2.logofinder

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext

/**
 * Reads your logo folder in the background, with a progress notification.
 * Keeps going with the screen off or while you use other apps.
 * Only new or changed pictures are read; progress is saved regularly, so it can always continue later.
 */
class IndexWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val ctx = applicationContext
        val tree = inputData.getString(KEY_FOLDER)?.let(Uri::parse) ?: return Result.failure()
        createChannel(ctx)
        goForeground("Looking through the folder…", 0, 0)

        val old = IndexStore.load(ctx).associateBy { it.uri }
        val files = try {
            FolderScanner.listImages(ctx, tree)
        } catch (e: SecurityException) {
            return Result.failure(workDataOf(KEY_ERROR to "No permission for the folder. Choose it again."))
        }

        // A library file shared by a partner, if one was imported.
        val seed = SharedLibrary.loadSeed(ctx)
        if (seed != null) goForeground("Using the shared library…", 0, 0)
        val sharedLearned = HashMap<String, List<Fingerprint>>()
        var reused = 0

        val kept = mutableListOf<LogoEntry>()
        val todo = mutableListOf<ImageFile>()
        for (f in files) {
            val uri = f.uri.toString()
            val existing = old[uri]
            val shared = seed?.match(f)
            if (shared != null && shared.learned.isNotEmpty()) sharedLearned[uri] = shared.learned
            when {
                existing != null && existing.modified == f.modified -> kept += existing
                shared != null -> {
                    val name = f.name.substringBeforeLast('.').ifBlank { "Unnamed" }
                    kept += LogoEntry(name, uri, f.modified, shared.fp)
                    reused++
                }
                else -> todo += f
            }
        }

        // Shared matches are ready right away: save them before reading anything else.
        if (seed != null) {
            IndexStore.save(ctx, kept.toList())
            if (sharedLearned.isNotEmpty()) IndexStore.savePendingLearned(ctx, sharedLearned)
            SharedLibrary.clearSeed(ctx)
        }

        if (todo.isEmpty()) {
            IndexStore.save(ctx, kept.sortedBy { it.name.lowercase() })
            return Result.success(workDataOf(KEY_COUNT to kept.size, KEY_FAILED to 0, KEY_REUSED to reused))
        }

        goForeground("Starting the AI models…", 0, todo.size)
        val engine = Engines.get(ctx)

        var failed = 0
        val started = System.currentTimeMillis()
        var lastSave = started
        var lastNotify = 0L
        try {
            todo.forEachIndexed { i, file ->
                coroutineContext.ensureActive()
                val bmp = Images.load(ctx.contentResolver, file.uri, 1024)
                if (bmp == null) {
                    failed++
                } else {
                    val name = file.name.substringBeforeLast('.').ifBlank { "Unnamed" }
                    kept += LogoEntry(name, file.uri.toString(), file.modified, engine.fingerprintLogo(bmp))
                }
                val done = i + 1
                val minutesLeft = (((todo.size - done) * ((System.currentTimeMillis() - started) / done)) / 60000).toInt()
                setProgress(workDataOf(KEY_DONE to done, KEY_TOTAL to todo.size, KEY_MINUTES to minutesLeft))

                val now = System.currentTimeMillis()
                if (now - lastNotify > 5_000) {
                    goForeground("Reading logo $done of ${todo.size}${timeLeftText(done, minutesLeft)}", done, todo.size)
                    lastNotify = now
                }
                // Save every 3 minutes, so if the phone stops the work, little is lost.
                // Also save after the first 25, so searching can start almost right away.
                if (now - lastSave > 3 * 60_000 || done == 25) {
                    IndexStore.save(ctx, kept.toList())
                    lastSave = now
                }
            }
        } catch (e: CancellationException) {
            // Stopped (by you or by Android): save everything read so far.
            withContext(NonCancellable) { IndexStore.save(ctx, kept.toList()) }
            throw e
        }

        IndexStore.save(ctx, kept.sortedBy { it.name.lowercase() })
        return Result.success(workDataOf(KEY_COUNT to kept.size, KEY_FAILED to failed, KEY_REUSED to reused))
    }

    private suspend fun goForeground(text: String, done: Int, total: Int) {
        try {
            setForeground(foregroundInfo(text, done, total))
        } catch (e: Exception) {
            // Some phones refuse when the app was restarted in the background; reading still continues.
        }
    }

    private fun foregroundInfo(text: String, done: Int, total: Int): ForegroundInfo {
        val ctx = applicationContext
        val openApp = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = WorkManager.getInstance(ctx).createCancelPendingIntent(id)
        val notification = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle("Logo Finder is reading your logos")
            .setContentText(text)
            .setProgress(total, done, total == 0)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stop)
            .build()
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            ForegroundInfo(NOTIFICATION_ID, notification)
        }
    }

    companion object {
        const val UNIQUE_NAME = "logo_indexing"
        const val KEY_FOLDER = "folder"
        const val KEY_DONE = "done"
        const val KEY_TOTAL = "total"
        const val KEY_MINUTES = "minutes"
        const val KEY_COUNT = "count"
        const val KEY_FAILED = "failed"
        const val KEY_ERROR = "error"
        const val KEY_REUSED = "reused"
        private const val CHANNEL_ID = "indexing"
        private const val NOTIFICATION_ID = 1001

        fun timeLeftText(done: Int, minutesLeft: Int): String = when {
            done < 5 -> "…"
            minutesLeft >= 60 -> ", about ${minutesLeft / 60} h ${minutesLeft % 60} min left"
            else -> ", about $minutesLeft min left"
        }

        private fun createChannel(ctx: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val nm = ctx.getSystemService(NotificationManager::class.java)
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, "Reading logos", NotificationManager.IMPORTANCE_LOW)
                )
            }
        }
    }
}
