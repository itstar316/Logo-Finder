package com.k2.logofinder

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("logo_finder", Context.MODE_PRIVATE)
    private var engineInstance: LogoEngine? = null

    @Synchronized
    private fun engine(): LogoEngine =
        engineInstance ?: LogoEngine(getApplication()).also { engineInstance = it }

    var entries by mutableStateOf<List<LogoEntry>>(emptyList())
        private set
    var status by mutableStateOf("Loading saved logos…")
        private set
    var progress by mutableStateOf<Float?>(null)
        private set
    var queryBitmap by mutableStateOf<Bitmap?>(null)
        private set
    var results by mutableStateOf<List<Match>>(emptyList())
        private set
    var searching by mutableStateOf(false)
        private set
    var folderUri by mutableStateOf(prefs.getString("folder", null)?.let(Uri::parse))
        private set

    private var indexJob: Job? = null
    private val loadJob: Job = viewModelScope.launch {
        entries = withContext(Dispatchers.IO) { IndexStore.load(getApplication()) }
        status = summary()
    }

    private fun summary() =
        if (entries.isEmpty()) "No logos yet. Choose the folder with your Wilcom pictures."
        else "${entries.size} logos ready to search"

    /** Reads the folder; only new or changed pictures are processed again. */
    fun indexFolder(tree: Uri? = folderUri) {
        if (tree == null || indexJob?.isActive == true) return
        prefs.edit().putString("folder", tree.toString()).apply()
        folderUri = tree
        indexJob = viewModelScope.launch {
            loadJob.join()
            val ctx: Application = getApplication()
            status = "Looking through the folder…"
            progress = 0f

            val old = entries.associateBy { it.uri }
            val kept = mutableListOf<LogoEntry>()
            val todo = mutableListOf<Pair<DocumentFile, Long>>()
            withContext(Dispatchers.IO) {
                for (f in listImages(ctx, tree)) {
                    val modified = f.lastModified()
                    val existing = old[f.uri.toString()]
                    if (existing != null && existing.modified == modified) kept += existing
                    else todo += f to modified
                }
            }

            var failed = 0
            withContext(Dispatchers.Default) {
                todo.forEachIndexed { i, (file, modified) ->
                    ensureActive()
                    val bmp = Images.load(ctx.contentResolver, file.uri, 640)
                    if (bmp == null) {
                        failed++
                    } else {
                        val name = file.name?.substringBeforeLast('.') ?: "Unnamed"
                        kept += LogoEntry(name, file.uri.toString(), modified, engine().fingerprintLogo(bmp))
                    }
                    withContext(Dispatchers.Main) {
                        progress = (i + 1f) / todo.size
                        status = "Reading logo ${i + 1} of ${todo.size}…"
                    }
                    if ((i + 1) % 50 == 0) IndexStore.save(ctx, kept.toList())
                }
            }

            val finalList = kept.sortedBy { it.name.lowercase() }
            withContext(Dispatchers.IO) { IndexStore.save(ctx, finalList) }
            entries = finalList
            progress = null
            status = summary() + if (failed > 0) ". $failed files could not be opened." else ""
        }
    }

    /** Finds the closest logos to the client's picture. */
    fun search(uri: Uri) {
        viewModelScope.launch {
            loadJob.join()
            searching = true
            results = emptyList()
            val ctx: Application = getApplication()
            val bmp = withContext(Dispatchers.IO) { Images.load(ctx.contentResolver, uri, 1024) }
            queryBitmap = bmp
            if (bmp == null) {
                status = "That picture could not be opened. Try saving it to the phone first."
                searching = false
                return@launch
            }
            val list = entries
            results = withContext(Dispatchers.Default) { Matcher.rank(engine().fingerprintQuery(bmp), list) }
            searching = false
        }
    }

    private fun listImages(ctx: Context, tree: Uri): List<DocumentFile> {
        val root = DocumentFile.fromTreeUri(ctx, tree) ?: return emptyList()
        val out = mutableListOf<DocumentFile>()
        fun walk(dir: DocumentFile) {
            for (f in dir.listFiles()) {
                if (f.isDirectory) walk(f)
                else if (f.type?.startsWith("image/") == true) out += f
            }
        }
        walk(root)
        return out
    }

    override fun onCleared() {
        engineInstance?.close()
    }
}
