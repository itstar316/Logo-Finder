package com.k2.logofinder

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.workDataOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("logo_finder", Context.MODE_PRIVATE)
    private val workManager = WorkManager.getInstance(app)

    var entries by mutableStateOf<List<LogoEntry>>(emptyList())
        private set
    var status by mutableStateOf("Loading saved logos…")
        private set
    var progress by mutableStateOf<Float?>(null)
        private set
    var queryBitmap by mutableStateOf<Bitmap?>(null)
        private set
    var searchedBitmap by mutableStateOf<Bitmap?>(null)
        private set
    var queryWords by mutableStateOf<Set<String>>(emptySet())
        private set
    var results by mutableStateOf<List<Match>>(emptyList())
        private set
    var searching by mutableStateOf(false)
        private set
    var folderUri by mutableStateOf(prefs.getString("folder", null)?.let(Uri::parse))
        private set
    var lastUpdated by mutableStateOf(prefs.getLong("updated", 0L))
        private set
    var recents by mutableStateOf<List<Recent>>(emptyList())
        private set
    var reading by mutableStateOf(false)
        private set
    var readDone by mutableStateOf(0)
        private set
    var readTotal by mutableStateOf(0)
        private set
    var readMinutesLeft by mutableStateOf(0)
        private set
    /** Logos in an imported shared library, waiting for the folder to be chosen (0 = none). */
    var sharedWaiting by mutableStateOf(0)
        private set
    var sharingBusy by mutableStateOf(false)
        private set

    /** Folder name to show, e.g. "Pictures/K2 Logos". */
    val folderName: String?
        get() = folderUri?.let {
            try {
                android.provider.DocumentsContract.getTreeDocumentId(it).substringAfter(':').ifBlank { "Phone storage" }
            } catch (e: Exception) {
                null
            }
        }

    private var learned: Map<String, List<Fingerprint>> = emptyMap()
    private var lastQuery: Fingerprint? = null
    private var sawRunning = false
    private var lastPartialReload = 0L

    private val loadJob: Job = viewModelScope.launch { reload() }

    init {
        // Follow the background reader and show its progress here.
        viewModelScope.launch {
            loadJob.join()
            workManager.getWorkInfosForUniqueWorkFlow(IndexWorker.UNIQUE_NAME).collect { infos ->
                val info = infos.lastOrNull() ?: return@collect
                when (info.state) {
                    WorkInfo.State.ENQUEUED, WorkInfo.State.BLOCKED -> {
                        sawRunning = true
                        reading = true
                        readDone = 0
                        readTotal = 0
                        progress = progress ?: 0f
                        status = "Waiting to start reading…"
                    }
                    WorkInfo.State.RUNNING -> {
                        sawRunning = true
                        val done = info.progress.getInt(IndexWorker.KEY_DONE, 0)
                        val total = info.progress.getInt(IndexWorker.KEY_TOTAL, 0)
                        val minutes = info.progress.getInt(IndexWorker.KEY_MINUTES, 0)
                        reading = true
                        readDone = done
                        readTotal = total
                        readMinutesLeft = minutes
                        // While reading, pick up the logos saved so far every couple of minutes,
                        // so you can already search them.
                        val now = System.currentTimeMillis()
                        if (done > 0 && now - lastPartialReload > 2 * 60_000) {
                            lastPartialReload = now
                            launch { reload() }
                        }
                        progress = if (total > 0) done.toFloat() / total else 0f
                        status = if (total > 0) "Reading logo $done of $total" + IndexWorker.timeLeftText(done, minutes)
                        else "Looking through the folder…"
                    }
                    WorkInfo.State.SUCCEEDED -> if (sawRunning) {
                        sawRunning = false
                        reading = false
                        lastUpdated = System.currentTimeMillis()
                        prefs.edit().putLong("updated", lastUpdated).apply()
                        progress = null
                        reload()
                        val failed = info.outputData.getInt(IndexWorker.KEY_FAILED, 0)
                        val reused = info.outputData.getInt(IndexWorker.KEY_REUSED, 0)
                        status = summary() +
                            (if (reused > 0) ". %,d came from the shared library".format(reused) else "") +
                            (if (failed > 0) ". $failed files could not be opened." else "")
                    }
                    WorkInfo.State.CANCELLED -> if (sawRunning) {
                        sawRunning = false
                        reading = false
                        progress = null
                        reload()
                        status = "Stopped at ${entries.size} logos. Tap “Check for new logos” to continue."
                    }
                    WorkInfo.State.FAILED -> if (sawRunning) {
                        sawRunning = false
                        reading = false
                        progress = null
                        reload()
                        status = info.outputData.getString(IndexWorker.KEY_ERROR) ?: "Reading stopped with an error. Try again."
                    }
                }
            }
        }
    }

    private suspend fun reload() {
        val (index, learnedMap) = withContext(Dispatchers.IO) {
            val ctx: Application = getApplication()
            val saved = IndexStore.loadLearned(ctx)
            val pending = IndexStore.takePendingLearned(ctx)
            val merged = if (pending.isEmpty()) saved else {
                val m = HashMap(saved)
                for ((uri, list) in pending) m[uri] = ((m[uri] ?: emptyList()) + list).takeLast(MAX_LEARNED)
                IndexStore.saveLearned(ctx, m)
                m
            }
            IndexStore.load(ctx) to merged
        }
        sharedWaiting = withContext(Dispatchers.IO) {
            val ctx: Application = getApplication()
            if (SharedLibrary.hasSeed(ctx)) SharedLibrary.seedCount(ctx) else 0
        }
        if (recents.isEmpty()) recents = withContext(Dispatchers.IO) { RecentStore.load(getApplication()) }
        learned = learnedMap
        entries = index.map { e -> LogoEntry(e.name, e.uri, e.modified, e.fp, learnedMap[e.uri] ?: emptyList()) }
        if (progress == null) status = summary()
    }

    private fun summary() =
        if (entries.isEmpty()) "No logos yet. Choose the folder with your Wilcom pictures."
        else "${entries.size} logos ready to search"

    /** Starts (or continues) reading the folder in the background. */
    fun indexFolder(tree: Uri? = folderUri) {
        if (tree == null) return
        prefs.edit().putString("folder", tree.toString()).apply()
        folderUri = tree
        val request = OneTimeWorkRequestBuilder<IndexWorker>()
            .setInputData(workDataOf(IndexWorker.KEY_FOLDER to tree.toString()))
            .build()
        workManager.enqueueUniqueWork(IndexWorker.UNIQUE_NAME, ExistingWorkPolicy.KEEP, request)
        sharedWaiting = 0
    }

    fun stopIndexing() {
        workManager.cancelUniqueWork(IndexWorker.UNIQUE_NAME)
    }

    /** Search with a picture from the gallery or shared from Gmail / WhatsApp. */
    fun search(uri: Uri) {
        viewModelScope.launch {
            val bmp = withContext(Dispatchers.IO) { Images.load(getApplication<Application>().contentResolver, uri, 1600) }
            if (bmp == null) {
                status = "That picture could not be opened. Try saving it to the phone first."
                return@launch
            }
            queryBitmap = bmp
            runSearch(bmp, userCropped = false)
        }
    }

    /** Makes the library file to send to a partner. Calls back with the file, or null if it failed. */
    fun exportLibrary(onReady: (java.io.File?, Int) -> Unit) {
        val folder = folderUri ?: return onReady(null, 0)
        if (sharingBusy) return
        sharingBusy = true
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching { SharedLibrary.export(getApplication(), folder, entries, learned) }.getOrNull()
            }
            sharingBusy = false
            onReady(result?.first, result?.second ?: 0)
        }
    }

    /** Opens a library file from a partner. Calls back with an error message, or null when ready. */
    fun importLibrary(uri: Uri, onDone: (String?) -> Unit) {
        if (sharingBusy) return
        sharingBusy = true
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { SharedLibrary.importFile(getApplication(), uri) }
            sharingBusy = false
            result.onSuccess { sharedWaiting = it; onDone(null) }
                .onFailure { onDone(it.message ?: "This file could not be opened.") }
        }
    }

    fun cancelImport() {
        SharedLibrary.clearSeed(getApplication())
        sharedWaiting = 0
    }

    /** Back to the home screen. */
    fun clearSearch() {
        searchedBitmap = null
        queryBitmap = null
        results = emptyList()
        queryWords = emptySet()
    }

    /** Search again with only the part you selected. */
    fun searchCropped(cropped: Bitmap) {
        viewModelScope.launch { runSearch(cropped, userCropped = true) }
    }

    private suspend fun runSearch(bmp: Bitmap, userCropped: Boolean) {
        loadJob.join()
        searching = true
        // Search everything read so far, including logos read in the last few minutes.
        if (reading) reload()
        results = emptyList()
        searchedBitmap = bmp
        val list = entries
        val (fp, ranked) = withContext(Dispatchers.Default) {
            val fp = Engines.get(getApplication()).fingerprintQuery(bmp, userCropped)
            fp to Matcher.rank(fp, list, TOP_RESULTS)
        }
        lastQuery = fp
        queryWords = fp.words
        results = ranked
        searching = false
    }

    /** You confirmed this is the right logo: remember the client's photo for next time. */
    fun confirm(match: Match) {
        val q = lastQuery ?: return
        val uri = match.entry.uri
        val list = ((learned[uri] ?: emptyList()) + q).takeLast(MAX_LEARNED)
        val updated = learned + (uri to list)
        learned = updated
        entries = entries.map { e ->
            if (e.uri == uri) LogoEntry(e.name, e.uri, e.modified, e.fp, list) else e
        }
        val picture = searchedBitmap
        val currentRecents = recents
        viewModelScope.launch(Dispatchers.IO) {
            IndexStore.saveLearned(getApplication(), updated)
            if (picture != null) {
                val newRecents = RecentStore.add(getApplication(), currentRecents, match.entry.name, uri, picture)
                withContext(Dispatchers.Main) { recents = newRecents }
            }
        }
    }

    companion object {
        const val TOP_RESULTS = 40
        private const val MAX_LEARNED = 10
    }
}
