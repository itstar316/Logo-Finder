package com.k2.logofinder

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import android.provider.DocumentsContract
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("logo_finder", Context.MODE_PRIVATE)
    private var engineInstance: LogoEngine? = null

    @Synchronized
    private fun engine(): LogoEngine =
        engineInstance ?: LogoEngine(getApplication()).also { engineInstance = it }

    var entries by mutableStateOf<List<LogoEntry>>(emptyList())
        private set
    var status by mutableStateOf("Loading saved logos…")
        private set
    var progress by mutableStateOf<Float?>(null)
        private set
    var queryBitmap by mutableStateOf<Bitmap?>(null)
        private set
    var searchedBitmap by mutableStateOf<Bitmap?>(null)
        private set
    var queryWords by mutableStateOf<Set<String>>(emptySet())
        private set
    var results by mutableStateOf<List<Match>>(emptyList())
        private set
    var searching by mutableStateOf(false)
        private set
    var folderUri by mutableStateOf(prefs.getString("folder", null)?.let(Uri::parse))
        private set

    private var lastQuery: Fingerprint? = null
    private var indexJob: Job? = null
    private val loadJob: Job = viewModelScope.launch {
        entries = withContext(Dispatchers.IO) { IndexStore.load(getApplication()) }
        status = summary()
    }

    private fun summary() =
        if (entries.isEmpty()) "No logos yet. Choose the folder with your Wilcom pictures."
        else "${entries.size} logos ready to search"

    /** Reads the folder; only new or changed pictures are processed. Safe to stop and continue later. */
    fun indexFolder(tree: Uri? = folderUri) {
        if (tree == null || indexJob?.isActive == true) return
        prefs.edit().putString("folder", tree.toString()).apply()
        folderUri = tree
        indexJob = viewModelScope.launch {
            loadJob.join()
            val ctx: Application = getApplication()
            status = "Looking through the folder…"
            progress = 0f

            val old = entries.associateBy { it.uri }
            val kept = mutableListOf<LogoEntry>()
            val todo = mutableListOf<ImageFile>()
            withContext(Dispatchers.IO) {
                for (f in listImages(ctx, tree)) {
                    val existing = old[f.uri.toString()]
                    if (existing != null && existing.modified == f.modified) kept += existing
                    else todo += f
                }
            }

            if (todo.isNotEmpty()) {
                status = "Starting the AI models…"
                withContext(Dispatchers.Default) { engine() }
            }

            var failed = 0
            val started = System.currentTimeMillis()
            var lastSave = started
            withContext(Dispatchers.Default) {
              try {
                todo.forEachIndexed { i, file ->
                    ensureActive()
                    val bmp = Images.load(ctx.contentResolver, file.uri, 1024)
                    if (bmp == null) {
                        failed++
                    } else {
                        val uri = file.uri.toString()
                        val name = file.name.substringBeforeLast('.').ifBlank { "Unnamed" }
                        // Keep what was learned for this logo even if the picture file changed.
                        val learned = old[uri]?.learned ?: emptyList()
                        kept += LogoEntry(name, uri, file.modified, engine().fingerprintLogo(bmp), learned)
                    }
                    val done = i + 1
                    val perItem = (System.currentTimeMillis() - started) / done
                    val minutesLeft = ((todo.size - done) * perItem / 60000).toInt()
                    withContext(Dispatchers.Main) {
                        progress = done.toFloat() / todo.size
                        status = "Reading logo $done of ${todo.size}" +
                            if (done < 5) "…"
                            else if (minutesLeft >= 60) ", about ${minutesLeft / 60} h ${minutesLeft % 60} min left"
                            else ", about $minutesLeft min left"
                    }
                    // Save progress every 3 minutes, so stopping never loses much work.
                    if (System.currentTimeMillis() - lastSave > 3 * 60_000) {
                        IndexStore.save(ctx, kept.toList())
                        lastSave = System.currentTimeMillis()
                    }
                }
              } catch (e: CancellationException) {
                // Stopped: save everything read so far, so "Check for new logos" continues from here.
                withContext(NonCancellable) { IndexStore.save(ctx, kept.toList()) }
                throw e
              }
            }

            val finalList = kept.sortedBy { it.name.lowercase() }
            withContext(Dispatchers.IO) { IndexStore.save(ctx, finalList) }
            entries = finalList
            progress = null
            status = summary() + if (failed > 0) ". $failed files could not be opened." else ""
        }
    }

    fun stopIndexing() {
        val job = indexJob ?: return
        viewModelScope.launch {
            job.cancel()
            job.join()
            progress = null
            status = "Stopped. Tap “Check for new logos” to continue where it left off."
            entries = withContext(Dispatchers.IO) { IndexStore.load(getApplication()) }
        }
    }

    /** Search with a picture from the gallery or shared from Gmail / WhatsApp. */
    fun search(uri: Uri) {
        viewModelScope.launch {
            val bmp = withContext(Dispatchers.IO) { Images.load(getApplication<Application>().contentResolver, uri, 1600) }
            if (bmp == null) {
                status = "That picture could not be opened. Try saving it to the phone first."
                return@launch
            }
            queryBitmap = bmp
            runSearch(bmp, userCropped = false)
        }
    }

    /** Search again with only the part you selected. */
    fun searchCropped(cropped: Bitmap) {
        viewModelScope.launch { runSearch(cropped, userCropped = true) }
    }

    private suspend fun runSearch(bmp: Bitmap, userCropped: Boolean) {
        loadJob.join()
        searching = true
        results = emptyList()
        searchedBitmap = bmp
        val list = entries
        val (fp, ranked) = withContext(Dispatchers.Default) {
            val fp = engine().fingerprintQuery(bmp, userCropped)
            fp to Matcher.rank(fp, list, TOP_RESULTS)
        }
        lastQuery = fp
        queryWords = fp.words
        results = ranked
        searching = false
    }

    /** You confirmed this is the right logo: remember the client's photo for next time. */
    fun confirm(match: Match) {
        val q = lastQuery ?: return
        val updated = entries.map { e ->
            if (e.uri == match.entry.uri) {
                val learned = (e.learned + q).takeLast(MAX_LEARNED)
                LogoEntry(e.name, e.uri, e.modified, e.fp, learned)
            } else e
        }
        entries = updated
        viewModelScope.launch(Dispatchers.IO) { IndexStore.save(getApplication(), updated) }
    }

    private class ImageFile(val uri: Uri, val name: String, val modified: Long)

    /** Lists all pictures in the folder and its subfolders, quickly (one query per folder). */
    private fun listImages(ctx: Context, tree: Uri): List<ImageFile> {
        val out = mutableListOf<ImageFile>()
        val columns = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED
        )
        fun walk(docId: String) {
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            ctx.contentResolver.query(children, columns, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0) ?: continue
                    val name = c.getString(1) ?: ""
                    val mime = c.getString(2) ?: ""
                    val modified = if (c.isNull(3)) 0L else c.getLong(3)
                    when {
                        mime == DocumentsContract.Document.MIME_TYPE_DIR -> walk(id)
                        mime.startsWith("image/") ->
                            out += ImageFile(DocumentsContract.buildDocumentUriUsingTree(tree, id), name, modified)
                    }
                }
            }
        }
        walk(DocumentsContract.getTreeDocumentId(tree))
        return out
    }

    override fun onCleared() {
        engineInstance?.close()
    }

    companion object {
        const val TOP_RESULTS = 40
        private const val MAX_LEARNED = 10
    }
}
