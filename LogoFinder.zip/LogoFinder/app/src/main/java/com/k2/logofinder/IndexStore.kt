package com.k2.logofinder

import android.content.Context
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * One of your digitized pictures.
 * [learned] holds client photos you confirmed as this logo, so the same photo is found instantly next time.
 */
class LogoEntry(
    val name: String,
    val uri: String,
    val modified: Long,
    val fp: Fingerprint,
    val learned: List<Fingerprint> = emptyList()
)

/** Keeps the index in the app's private storage so it survives restarts. */
object IndexStore {
    private const val VERSION = 3
    private const val FILE_NAME = "logo_index_v3.bin"

    @Synchronized
    fun save(ctx: Context, entries: List<LogoEntry>) {
        val tmp = File(ctx.filesDir, "$FILE_NAME.tmp")
        DataOutputStream(BufferedOutputStream(FileOutputStream(tmp), 1 shl 16)).use { out ->
            out.writeInt(VERSION)
            out.writeInt(entries.size)
            for (e in entries) {
                out.writeUTF(e.name)
                out.writeUTF(e.uri)
                out.writeLong(e.modified)
                writeFp(out, e.fp)
                out.writeInt(e.learned.size)
                for (l in e.learned) writeFp(out, l)
            }
        }
        tmp.renameTo(File(ctx.filesDir, FILE_NAME))
    }

    fun load(ctx: Context): List<LogoEntry> {
        val file = File(ctx.filesDir, FILE_NAME)
        if (!file.exists()) return emptyList()
        return try {
            DataInputStream(BufferedInputStream(FileInputStream(file), 1 shl 16)).use { inp ->
                if (inp.readInt() != VERSION) return emptyList()
                List(inp.readInt()) {
                    val name = inp.readUTF()
                    val uri = inp.readUTF()
                    val modified = inp.readLong()
                    val fp = readFp(inp)
                    val learned = List(inp.readInt()) { readFp(inp) }
                    LogoEntry(name, uri, modified, fp, learned)
                }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun writeFp(out: DataOutputStream, fp: Fingerprint) {
        out.writeInt(fp.views.size)
        for (v in fp.views) {
            writeVec(out, v.dino)
            writeVec(out, v.mobile)
            out.writeFloat(v.weight)
        }
        out.writeUTF(fp.words.joinToString(" "))
    }

    private fun readFp(inp: DataInputStream): Fingerprint {
        val views = List(inp.readInt()) {
            val d = readVec(inp)
            val m = readVec(inp)
            LogoView(d, m, inp.readFloat())
        }
        val words = inp.readUTF().split(" ").filter { it.isNotBlank() }.toSet()
        return Fingerprint(views, words)
    }

    private fun writeVec(out: DataOutputStream, v: Vec) {
        out.writeInt(v.q.size)
        out.writeFloat(v.scale)
        out.write(v.q)
    }

    private fun readVec(inp: DataInputStream): Vec {
        val size = inp.readInt()
        val scale = inp.readFloat()
        val q = ByteArray(size)
        inp.readFully(q)
        return Vec(q, scale)
    }
}
