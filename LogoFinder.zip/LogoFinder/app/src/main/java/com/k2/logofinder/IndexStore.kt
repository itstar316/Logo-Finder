package com.k2.logofinder

import android.content.Context
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/** One of your digitized pictures, with its name and fingerprint. */
class LogoEntry(val name: String, val uri: String, val modified: Long, val fp: Fingerprint)

/** Keeps the index in the app's private storage so it survives restarts. */
object IndexStore {
    private const val VERSION = 1
    private const val FILE_NAME = "logo_index.bin"

    fun save(ctx: Context, entries: List<LogoEntry>) {
        val tmp = File(ctx.filesDir, "$FILE_NAME.tmp")
        DataOutputStream(BufferedOutputStream(FileOutputStream(tmp))).use { out ->
            out.writeInt(VERSION)
            out.writeInt(entries.size)
            for (e in entries) {
                out.writeUTF(e.name)
                out.writeUTF(e.uri)
                out.writeLong(e.modified)
                out.writeInt(e.fp.views.size)
                for (v in e.fp.views) {
                    out.writeInt(v.size)
                    for (f in v) out.writeFloat(f)
                }
                out.writeUTF(e.fp.words.joinToString(" "))
            }
        }
        tmp.renameTo(File(ctx.filesDir, FILE_NAME))
    }

    fun load(ctx: Context): List<LogoEntry> {
        val file = File(ctx.filesDir, FILE_NAME)
        if (!file.exists()) return emptyList()
        return try {
            DataInputStream(BufferedInputStream(FileInputStream(file))).use { inp ->
                if (inp.readInt() != VERSION) return emptyList()
                List(inp.readInt()) {
                    val name = inp.readUTF()
                    val uri = inp.readUTF()
                    val modified = inp.readLong()
                    val views = List(inp.readInt()) { FloatArray(inp.readInt()) { inp.readFloat() } }
                    val words = inp.readUTF().split(" ").filter { it.isNotBlank() }.toSet()
                    LogoEntry(name, uri, modified, Fingerprint(views, words))
                }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
