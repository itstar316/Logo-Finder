package com.k2.logofinder

import android.content.Context
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * One of your digitized pictures.
 * [learned] holds client photos you confirmed as this logo, so the same photo is found instantly next time.
 */
class LogoEntry(
    val name: String,
    val uri: String,
    val modified: Long,
    val fp: Fingerprint,
    val learned: List<Fingerprint> = emptyList()
)

/**
 * Two files in the app's private storage:
 * - the logo index (written only by the background reader)
 * - the learned client photos (written only when you confirm a match)
 * Keeping them separate means confirming a match while reading is running never loses anything.
 */
object IndexStore {
    private const val VERSION = 4
    private const val INDEX_FILE = "logo_index_v4.bin"
    private const val LEARNED_FILE = "learned_v1.bin"
    private const val PENDING_LEARNED_FILE = "learned_pending.bin"

    @Synchronized
    fun save(ctx: Context, entries: List<LogoEntry>) = writeAtomically(ctx, INDEX_FILE) { out ->
        out.writeInt(VERSION)
        out.writeInt(entries.size)
        for (e in entries) {
            out.writeUTF(e.name)
            out.writeUTF(e.uri)
            out.writeLong(e.modified)
            writeFp(out, e.fp)
        }
    }

    @Synchronized
    fun load(ctx: Context): List<LogoEntry> = read(ctx, INDEX_FILE, emptyList()) { inp ->
        if (inp.readInt() != VERSION) return@read emptyList()
        List(inp.readInt()) {
            val name = inp.readUTF()
            val uri = inp.readUTF()
            val modified = inp.readLong()
            LogoEntry(name, uri, modified, readFp(inp))
        }
    }

    @Synchronized
    fun saveLearned(ctx: Context, learned: Map<String, List<Fingerprint>>) = saveLearnedTo(ctx, LEARNED_FILE, learned)

    @Synchronized
    fun loadLearned(ctx: Context): Map<String, List<Fingerprint>> = loadLearnedFrom(ctx, LEARNED_FILE)

    /** Confirmed matches that came with an imported shared library, waiting to be merged. */
    @Synchronized
    fun savePendingLearned(ctx: Context, learned: Map<String, List<Fingerprint>>) =
        saveLearnedTo(ctx, PENDING_LEARNED_FILE, learned)

    @Synchronized
    fun takePendingLearned(ctx: Context): Map<String, List<Fingerprint>> {
        val map = loadLearnedFrom(ctx, PENDING_LEARNED_FILE)
        File(ctx.filesDir, PENDING_LEARNED_FILE).delete()
        return map
    }

    private fun saveLearnedTo(ctx: Context, fileName: String, learned: Map<String, List<Fingerprint>>) =
        writeAtomically(ctx, fileName) { out ->
        out.writeInt(1)
        out.writeInt(learned.size)
        for ((uri, list) in learned) {
            out.writeUTF(uri)
            out.writeInt(list.size)
            for (fp in list) writeFp(out, fp)
        }
    }

    private fun loadLearnedFrom(ctx: Context, fileName: String): Map<String, List<Fingerprint>> =
        read(ctx, fileName, emptyMap()) { inp ->
        if (inp.readInt() != 1) return@read emptyMap()
        val map = HashMap<String, List<Fingerprint>>()
        repeat(inp.readInt()) {
            val uri = inp.readUTF()
            map[uri] = List(inp.readInt()) { readFp(inp) }
        }
        map
    }

    private fun writeAtomically(ctx: Context, name: String, block: (DataOutputStream) -> Unit) {
        val tmp = File(ctx.filesDir, "$name.tmp")
        DataOutputStream(BufferedOutputStream(FileOutputStream(tmp), 1 shl 16)).use(block)
        tmp.renameTo(File(ctx.filesDir, name))
    }

    private fun <T> read(ctx: Context, name: String, empty: T, block: (DataInputStream) -> T): T {
        val file = File(ctx.filesDir, name)
        if (!file.exists()) return empty
        return try {
            DataInputStream(BufferedInputStream(FileInputStream(file), 1 shl 16)).use(block)
        } catch (e: Exception) {
            empty
        }
    }

    fun writeFp(out: DataOutputStream, fp: Fingerprint) {
        out.writeInt(fp.views.size)
        for (v in fp.views) {
            writeVec(out, v.dino)
            writeVec(out, v.mobile)
            out.writeFloat(v.weight)
        }
        out.writeUTF(fp.words.joinToString(" "))
    }

    fun readFp(inp: DataInputStream): Fingerprint {
        val views = List(inp.readInt()) {
            val d = readVec(inp)
            val m = readVec(inp)
            LogoView(d, m, inp.readFloat())
        }
        val words = inp.readUTF().split(" ").filter { it.isNotBlank() }.toSet()
        return Fingerprint(views, words)
    }

    private fun writeVec(out: DataOutputStream, v: Vec) {
        out.writeInt(v.q.size)
        out.writeFloat(v.scale)
        out.write(v.q)
    }

    private fun readVec(inp: DataInputStream): Vec {
        val size = inp.readInt()
        val scale = inp.readFloat()
        val q = ByteArray(size)
        inp.readFully(q)
        return Vec(q, scale)
    }
}
