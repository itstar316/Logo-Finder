package com.k2.logofinder

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** Navy fabric, gold thread, cool canvas. */
object Palette {
    val Navy = Color(0xFF1B2338)
    val Thread = Color(0xFFD4A72C)
    val ThreadDeep = Color(0xFFA67F12)
    val Canvas = Color(0xFFF4F5F8)
    val Ink = Color(0xFF151A26)
    val Slate = Color(0xFF5B6274)
    val Ready = Color(0xFF2E8B62)
}

private val LightColors = lightColorScheme(
    primary = Palette.Navy,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDDE3F3),
    onPrimaryContainer = Palette.Navy,
    secondary = Palette.ThreadDeep,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFBEFC8),
    onSecondaryContainer = Color(0xFF3A2C00),
    background = Palette.Canvas,
    onBackground = Palette.Ink,
    surface = Palette.Canvas,
    onSurface = Palette.Ink,
    surfaceVariant = Color(0xFFE6E9F0),
    onSurfaceVariant = Palette.Slate,
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = Color.White,
    surfaceContainer = Color(0xFFEDEFF4),
    surfaceContainerHigh = Color(0xFFE6E9F0),
    outline = Color(0xFFB9BFCC),
    outlineVariant = Color(0xFFDADFE8),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFB9C6EE),
    onPrimary = Color(0xFF16213B),
    primaryContainer = Color(0xFF2B3654),
    onPrimaryContainer = Color(0xFFDDE3F3),
    secondary = Palette.Thread,
    onSecondary = Color(0xFF2A2000),
    secondaryContainer = Color(0xFF4A3A0A),
    onSecondaryContainer = Color(0xFFFBEFC8),
    background = Color(0xFF10141F),
    onBackground = Color(0xFFE4E7EF),
    surface = Color(0xFF10141F),
    onSurface = Color(0xFFE4E7EF),
    surfaceVariant = Color(0xFF2A3142),
    onSurfaceVariant = Color(0xFFB4BAC8),
    surfaceContainerLowest = Color(0xFF0C0F18),
    surfaceContainerLow = Color(0xFF181D2A),
    surfaceContainer = Color(0xFF1C2230),
    surfaceContainerHigh = Color(0xFF242B3B),
    outline = Color(0xFF5A6276),
    outlineVariant = Color(0xFF353C4D),
)

private val base = Typography()
private val AppTypography = Typography(
    headlineMedium = base.headlineMedium.copy(fontWeight = FontWeight.SemiBold, letterSpacing = (-0.5).sp),
    headlineSmall = base.headlineSmall.copy(fontWeight = FontWeight.SemiBold, letterSpacing = (-0.25).sp),
    titleLarge = base.titleLarge.copy(fontWeight = FontWeight.SemiBold),
    titleMedium = base.titleMedium.copy(fontWeight = FontWeight.SemiBold),
    bodyLarge = base.bodyLarge.copy(lineHeight = 24.sp),
    labelLarge = base.labelLarge.copy(fontWeight = FontWeight.SemiBold),
)

@Composable
fun LogoFinderTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        typography = AppTypography,
        content = content
    )
}

/** Gold thread colour, a little brighter in dark mode. */
val threadColor: Color
    @Composable get() = if (isSystemInDarkTheme()) Palette.Thread else Palette.ThreadDeep

