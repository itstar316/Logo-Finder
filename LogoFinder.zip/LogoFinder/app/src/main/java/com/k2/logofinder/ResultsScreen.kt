package com.k2.logofinder

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp

@Composable
fun ResultsScreen(
    vm: MainViewModel,
    onBack: () -> Unit,
    onCrop: () -> Unit,
    onCompare: (Match) -> Unit,
    onConfirm: (Match) -> Unit,
    onCopy: (String) -> Unit,
) {
    // Nothing to show while animating back to the home screen.
    if (vm.searchedBitmap == null) return
    val best = vm.results.firstOrNull()
    val others = vm.results.drop(1)

    LazyVerticalGrid(
        columns = GridCells.Adaptive(156.dp),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 32.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        full {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(AppIcons.Back, "Back") }
                Text("Matches", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                if (vm.queryBitmap != null && !vm.searching) {
                    TextButton(onClick = onCrop) {
                        Icon(AppIcons.Crop, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Crop")
                    }
                }
            }
        }

        full { QueryHeader(vm) }

        if (vm.searching) {
            items(6) { SkeletonCard() }
            return@LazyVerticalGrid
        }

        if (best == null) {
            full {
                Text(
                    "No logos to compare yet. Wait for reading to finish, then search again.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            return@LazyVerticalGrid
        }

        full { SectionTitle("Best match") }
        full { BestMatchCard(best, onConfirm = { onConfirm(best) }, onCompare = { onCompare(best) }) }

        if (others.isNotEmpty()) {
            full { SectionTitle("Other close matches", "Tap one to compare it with the client’s picture") }
            itemsIndexed(others, key = { _, m -> m.entry.uri }) { i, m ->
                MatchCard(rank = i + 2, match = m, onClick = { onCompare(m) }, onCopy = { onCopy(m.entry.name) })
            }
        }

        full {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.padding(top = 8.dp)
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Not here?", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "Crop to just the logo and search again. It helps a lot with photos of garments.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    OutlinedButton(onClick = onCrop) { Text("Crop") }
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String? = null) {
    Column(Modifier.padding(top = 12.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        if (subtitle != null) {
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun QueryHeader(vm: MainViewModel) {
    val bmp = vm.searchedBitmap ?: return
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(
            Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(20.dp))
                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
        ) {
            Image(
                bmp.asImageBitmap(), "Client's picture", contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize()
            )
            Pill(
                "Client’s picture", Color.Black.copy(alpha = 0.6f), Color.White,
                Modifier.align(Alignment.BottomStart).padding(10.dp)
            )
        }
        if (vm.searching) {
            Text(
                "Comparing with %,d logos…".format(vm.entries.size),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            LinearProgressIndicator(color = threadColor, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(50)))
        } else {
            WordsRead(vm.queryWords)
        }
    }
}

@Composable
private fun BestMatchCard(m: Match, onConfirm: () -> Unit, onCompare: () -> Unit) {
    Card(
        onClick = onCompare,
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        modifier = Modifier.fillMaxWidth().stitched(threadColor)
    ) {
        Column(Modifier.padding(14.dp)) {
            Box {
                LogoImage(
                    m.entry.uri, m.entry.name,
                    Modifier.fillMaxWidth().aspectRatio(1.6f).clip(RoundedCornerShape(16.dp)),
                    padding = 12.dp
                )
                if (m.fromLearned) {
                    Pill("Seen before", threadColor, Color.White, Modifier.align(Alignment.TopEnd).padding(8.dp))
                }
            }
            Spacer(Modifier.height(14.dp))
            Text(m.entry.name, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(horizontal = 4.dp))
            if (m.fromLearned) {
                Text(
                    "You confirmed this client picture before.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onConfirm,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f).height(52.dp)
                ) {
                    Icon(AppIcons.Check, null, Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("This is it, copy name")
                }
                OutlinedButton(
                    onClick = onCompare,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.height(52.dp)
                ) { Text("Compare") }
            }
        }
    }
}

@Composable
private fun SkeletonCard() {
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue = 0.4f, targetValue = 0.9f,
        animationSpec = infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "alpha"
    )
    Column(
        Modifier.clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surfaceContainerLow).alpha(pulse)
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(1f).background(MaterialTheme.colorScheme.surfaceContainerHigh))
        Box(
            Modifier.padding(12.dp).fillMaxWidth(0.7f).height(14.dp).clip(RoundedCornerShape(50))
                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
        )
    }
}
