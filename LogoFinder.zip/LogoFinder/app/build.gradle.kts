plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.k2.logofinder"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.k2.logofinder"
        minSdk = 24
        targetSdk = 34
        versionCode = 5
        versionName = "3.0.1"
        // Phones with 64-bit and 32-bit ARM chips (almost all Android phones)
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }

    // The same permanent key signs every build, so new versions install as updates
    // (no uninstalling, and your logo index and confirmed matches are kept).
    signingConfigs {
        create("k2") {
            storeFile = file("k2-logofinder.jks")
            storePassword = "rinb6xVnlKhwI7OYoToT"
            keyAlias = "logofinder"
            keyPassword = "rinb6xVnlKhwI7OYoToT"
        }
    }

    buildTypes {
        debug { signingConfig = signingConfigs.getByName("k2") }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("k2")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures { compose = true }

    // The AI model files must not be compressed
    androidResources { noCompress += listOf("tflite", "onnx") }

    // Avoid duplicate native-library errors between the AI libraries
    packaging { jniLibs { pickFirsts += "**/libc++_shared.so" } }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4")

    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.19.2")
    implementation("com.google.mediapipe:tasks-vision:0.10.14")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.8.1")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
    implementation("io.coil-kt:coil-compose:2.6.0")
}
