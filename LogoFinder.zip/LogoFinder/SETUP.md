# Logo Finder — GitHub + Codemagic setup

## 1. Unzip
Unzip LogoFinder.zip on your PC. Inside the LogoFinder folder you will see:

    app/
    build.gradle.kts
    codemagic.yaml
    gradle.properties
    settings.gradle.kts
    .gitignore      (may be hidden in Windows)
    SETUP.md

## 2. Upload to GitHub
1. On GitHub, create a new repository named LogoFinder (Private is fine).
2. Click "uploading an existing file".
3. Open the LogoFinder folder, select everything INSIDE it, and drag it into the browser.
   Upload the contents, not the zip and not the outer folder: codemagic.yaml must be at the top level of the repository.
4. Click "Commit changes".

## 3. Build on Codemagic
1. In Codemagic, add the LogoFinder repository as a new app.
2. Choose "codemagic.yaml" as the configuration (not the Workflow Editor).
3. Start a build of the "Logo Finder APK" workflow.
   Codemagic downloads the AI model and Gradle by itself, then builds the APK.
4. When it finishes, download app-debug.apk from the build's Artifacts and install it on your phone.

## 4. Put your logos on the phone
Copy your Wilcom pictures from the PC to a folder on the phone over USB, e.g. Pictures/K2 Logos. Subfolders are fine. File names are what the app shows ("Car logo", "Cat logo").

## 5. First use
1. Open the app, tap "Choose logo folder", pick K2 Logos, tap "Use this folder", then Allow.
2. Keep the app open while it reads all logos (a few minutes for about 2,000). This happens once; later, "Check for new logos" only reads new or changed files.
3. To search, tap "Search with client's picture", or in Gmail/WhatsApp tap Share on the client's picture and choose Logo Finder.
4. Tap the right result, tap "Copy name", and paste it into Gmail search.

## 6. Test the accuracy
Pick about 50 old cases where you already know the correct file. Search each one and note where the correct file appeared: #1, top 5, top 20, or missing. Send the results and the failed cases to Claude to tune or upgrade the model.

## If the build fails
Copy the red error lines from the Codemagic build log and paste them to Claude.
